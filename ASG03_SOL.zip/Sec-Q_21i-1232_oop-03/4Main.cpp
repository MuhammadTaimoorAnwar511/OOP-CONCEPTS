#include<iostream>
#include<ctime>
#include<iomanip>
#include"4Header.h"
using namespace std;

int main()
{
	srand(time(NULL));
	int con;
	int i = 0;
	int  n;                // dynamic memeory for student //
	int  roll = -1;       // roll number increment       //
	int ID = 0;          //id number for counsellor     //
	counsellor c1, c2, c3;// counsellor array            //

//--------------------------------------------------------------------------//

	do
	{
		cout << " Enter number of student \n= ";
		cin >> n;
	} while (n <= 0);

	student* std = new student[n];


	c1.set_student_ns(n);
	c2.set_student_ns(n);
	c3.set_student_ns(n);

	//------------------------------------------------------------------------//
	for (int s = 0;s < n;s++)
	{
		++roll;
		std[s].set_student_rollnumber(roll);

		cin >> std[s];
	}
	roll = 0;

	cout << "\n=======================\n";
	for (int s = 0;s < n;s++)
	{
		cout << "STUDENT # 0" << ++roll << endl;
		cout << std[s];
	}
	//----------------------------//
	ID = 1;
	cout << "Counsellor ID =" << ID << endl;
	c1.set_counsellor_id(ID);
	cin >> c1;
	ID = 2;
	cout << "Counsellor ID =" << ID << endl;
	c2.set_counsellor_id(ID);
	cin >> c2;
	ID = 3;
	cout << "Counsellor ID =" << ID << endl;
	c3.set_counsellor_id(ID);
	cin >> c3;
	cout << endl;
	cout << "\n=======================\n\n";
	cout << c1;
	cout << c2;
	cout << c3;
	cout << "\n=======================\n\n";
	c1 += std[n];
	c2 += std[n];
	c3 += std[n];
	cout << "\n=======================\n\n";
	cout << c1;
	cout << c2;
	cout << c3;

	cout << "\n========================================\n";
	cout << "\n****************************************\n";
	cout << "NAME =  ";
	cout << c1.get_name() << endl;
	cout << "student assing =  ";
	cout << c1.get_asg() << endl << endl;
	cout << "--------------------\n";
	con = c1.get_asg();

	for (int i = 0;i < con;i++)
	{
		cout << "student  number = " << i + 1 << endl;
		cout << std[c1.get_assign(i)] << endl;
	}
	cout << endl;
	cout << "\n****************************************\n";

	cout << "\n========================================\n";
	cout << "\n****************************************\n";
	cout << "NAME =  ";
	cout << c2.get_name() << endl;
	cout << "student assing =  ";
	cout << c2.get_asg() << endl << endl;
	cout << "--------------------\n";
	con = c2.get_asg();

	for (int i = 0;i < con;i++)
	{
		cout << "student  number = " << i + 1 << endl;
		cout << std[c2.get_assign(i)] << endl;
	}
	cout << endl;
	cout << "\n****************************************\n";

	cout << "\n========================================\n";
	cout << "\n****************************************\n";
	cout << "NAME =  ";
	cout << c3.get_name() << endl;
	cout << "student assing =  ";
	cout << c3.get_asg() << endl << endl;
	cout << "--------------------\n";
	con = c3.get_asg();

	for (int i = 0;i < con;i++)
	{
		cout << "student  number = " << i + 1 << endl;
		cout << std[c3.get_assign(i)] << endl;
	}

	cout << endl;
	cout << "\n****************************************\n";
	cout << "\nc1==c2\n";
	c1 == c2;
	cout << "\nc1<c2\n";
	c2 <c3;
	cout << "\nc1>c3\n";
	c1 > c3;
	cout << "\n****************************************\n";
	cout << c1;
	c1 -= std[n];
	cout << c1;
	cout << "\n****************************************\n";

	//-------//
	delete[]std;
	//-------//
	return 0;
}