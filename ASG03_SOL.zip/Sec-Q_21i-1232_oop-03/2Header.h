#pragma once
#include<iostream>
using namespace std;

class matrix
{
private:
	int row;
	int col;
	float** mat;

public:

	matrix ()
	{
		row = 0;
		col = 0;
	}
	 
	matrix(const matrix & matr)
	{

		row = matr.row;
		col = matr.col;

		mat = new float* [row];
		for (int r = 0;r < row;r++)
		{
			mat[r] = new float[col];
		}
		for (int r = 0;r < row;r++)
		{
			for (int c = 0;c < col;c++)
			{
				mat[r][c] = matr.mat[r][c];
			}
		}
	}
	
	matrix(int r, int c)
	{
		row = r;
		col = c;

		mat = new float* [row];
		for (int r = 0;r < row;r++)
		{
			mat[r] = new float[col];
		}
		for (int r = 0;r < row;r++)
		{
			for (int c = 0;c < col;c++)
			{
				mat[r][c] = 0;
			}
		}
	}
	float *& operator [] (int &col) const;

	friend  istream&  operator >> (istream& in, const matrix& m);
	friend  ostream&  operator << (ostream& out, const matrix& m);
	matrix  operator  = (const matrix& matr);
	matrix  operator  + (const  matrix& matr);
	matrix  operator  - (const  matrix& matr);
	matrix  operator  * (const  matrix& matr);
	matrix& operator += (int n);
	matrix& operator -= (int n);
	matrix& operator *= (int n);
	matrix& operator /= (int n);
	bool    operator == (const matrix& matr);
	matrix& operator()  (int A, int B);

	~matrix();
};