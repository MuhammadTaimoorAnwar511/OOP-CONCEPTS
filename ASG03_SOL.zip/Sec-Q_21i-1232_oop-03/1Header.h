  #pragma once
  #include<iostream>
  using namespace std;

class extented_character
{

private:
	char ch;
public:
	extented_character()
	{
		ch = '0';
	}
	extented_character(char c)
	{
		ch = c;
	}
	extented_character(int c)
	{
		ch = c;
	}
	void set_char(char c)
	{
		ch = c;
	}

	char get_char()
	{
		return ch;
	}
	string tostring(char c);
	
	//--------------------------------------------//
	friend  istream& operator   >> (istream& in, extented_character &c);
	friend  ostream& operator   << (ostream& out, extented_character &c);
	extented_character operator  + (const  extented_character& c);
	extented_character operator  - (const  extented_character& c);
	extented_character operator  = (const  extented_character& c);
	 operator  int ();
	 operator short();
	//--------------------------------------------//
	bool  operator == (const extented_character& c);
	bool  operator != (const extented_character& c);
	bool  operator <= (const extented_character& c);
	bool  operator >= (const extented_character& c);
	bool  operator <  (const extented_character& c);
	bool  operator >  (const extented_character& c);
	//--------------------------------------------//
	extented_character& operator ++();
	extented_character& operator ++(int);
	extented_character& operator --();
	extented_character& operator --(int);
	//-------------------------------------------//
	extented_character&  operator  () (int  a,int b);
	
		
	//-------------------------------------------//
};


void menu(extented_character& e1, extented_character& e2, extented_character& e3);

