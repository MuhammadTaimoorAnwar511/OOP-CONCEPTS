#include<iostream>
#include"2Header.h"
using namespace std;
//---------------------------------------------//
istream& operator >> (istream& in, const matrix& m)
{
	for (int r = 0;r < m.row;r++)
	{
		for (int c = 0;c < m.col;c++)
		{
			cout << "Enter value in row " << r + 1 << "  col " << c + 1 << endl;
			in >> m.mat[r][c];
		}
	}
	return in;
}
//---------------------------------------------//
ostream& operator << (ostream& out, const matrix& m)
{
	for (int r = 0;r < m.row;r++)
	{
		for (int c = 0;c < m.col;c++)
		{
			out << m.mat[r][c] << "  ";
		}
		cout << endl;
	}

	return out;
}
//--------------------------------------------//
matrix& matrix:: operator()(int A, int B)
{
	matrix temp(A,B);

	return temp;
}
//---------------------------------------------//
matrix matrix:: operator = (const matrix& matr)
{ 
	matrix temp(row,col);

	for (int r=0;r<row;r++)
	{
		for (int c=0;c<col;c++)
		{
			temp.mat[r][c]=matr.mat[r][c];
			mat[r][c]=temp.mat[r][c];
		}
	}

	return temp;
}
//----------------------------------------------//
matrix matrix :: operator * (const matrix& matr)
{
	matrix temp(row, col);

	for (int r = 0;r < row;r++)
	{
		for (int c = 0;c < col;c++)
		{
			temp.mat[r][c] = 0;
		}
	}

	for (int r = 0;r < row;r++)
	{
		for (int c = 0;c < col;c++)
		{
			for (int k = 0;k < col;k++)
			{
				temp.mat[r][c] = temp.mat[r][c] + (mat[r][k] * matr.mat[k][c]);
			}
		}
	}

	return temp;
}
//---------------------------------------------//
matrix matrix :: operator + (const matrix& matr)
{
	matrix temp(row, col);

	for (int r = 0;r < row;r++)
	{
		for (int c = 0;c < col;c++)
		{
			temp.mat[r][c] = mat[r][c] + matr.mat[r][c];
		}
	}

	return temp;
}
//---------------------------------------------//
matrix matrix :: operator - (const matrix& matr)
{
	matrix temp(row, col);

	for (int r = 0;r < row;r++)
	{
		for (int c = 0;c < col;c++)
		{
			temp.mat[r][c] = mat[r][c] - matr.mat[r][c];
		}
	}
	return temp;
}
//----------------------------------------------//
matrix& matrix:: operator += (int n)
{
	matrix temp(row, col);

	for (int r = 0;r < row;r++)
	{
		for (int c = 0;c < col;c++)
		{
			mat[r][c] = mat[r][c] + n;
		}
	}

	return temp;
}
//-----------------------------------------------//
matrix& matrix:: operator -= (int n)
{
	matrix temp(row, col);

	for (int r = 0;r < row;r++)
	{
		for (int c = 0;c < col;c++)
		{
			mat[r][c] = mat[r][c] - n;
		}
	}

	return temp;
}
//-----------------------------------------------//
matrix& matrix:: operator *= (int n)
{
	matrix temp(row, col);

	for (int r = 0;r < row;r++)
	{
		for (int c = 0;c < col;c++)
		{
			mat[r][c] = mat[r][c] * n;
		}
	}

	return temp;
}
//-----------------------------------------------//
matrix& matrix:: operator /= (int n)
{
	matrix temp(row, col);

	for (int r = 0; r < row;r++)
	{
		for (int c = 0;c < col;c++)
		{
			mat[r][c] = mat[r][c] / n;
		}
	}

	return temp;
}
//--------------------------------------------//

bool matrix ::  operator == (const matrix& matr)
{
	bool t=0,f=0;

	for (int r = 0; r < row;r++)
	{
		for (int c = 0;c < col;c++)
		{
			if (mat[r][c]==matr.mat[r][c])
			{
				t=1;
			}
			else
			{
				f=1;
			}
		}
	}
	if (t==1 && f==0)
	{
		cout << "\nEqual\n";
	}
	else
	{
		cout << "\nNot Equal\n";
	}
	return 0;
}
//--------------------------------------------//

float*& matrix:: operator [] (int& index) const  // overloading operator []
{
	return  mat[index];
}

//-----------------------------------------------//
matrix:: ~matrix()
{
	for (int i = 0;i < row;i++)
	{
		delete[] mat[i];
	}
	delete[] mat;
}
