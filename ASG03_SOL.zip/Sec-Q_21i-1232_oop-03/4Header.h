#pragma once
#include<iostream>
#include<string>
using namespace std;

class student
{
private:

	int    roll_number;
	char   name;
	string birth;
	string degree;
	int    batch;
	float  gpa;

public:

	student()
	{
		roll_number = 0;
		name = '0';
		batch = 0;
		gpa = 0;
		degree = "SE";
		birth = "january";
	}

	student(int NS, int roll, char naam, int bath, float GPA, string degre, string birthday)
	{

		roll_number = roll;
		name = naam;
		batch = bath;
		gpa = GPA;
		degree = degre;
		birth = birthday;
	}

	//###########################################################################//
	void set_student_rollnumber(int r)
	{
		roll_number = r;
	}
	int get_student_rollnumber()
	{
		return roll_number;
	}

	//###########################################################################//
	friend  istream& operator   >> (istream& in, student& STD);
	friend  ostream& operator   << (ostream& out, student& STD);
	//###########################################################################//
};

//###########################################################################//
//###########################################################################//
//###########################################################################//

class counsellor
{
private:

	int ns;
	int      id;
	int      asg;
	string   name;
	int* assign_std;

public:

	counsellor()
	{
		ns = 0;
		id = 0;
		asg = 0;
		name = "0";
		assign_std = new int[asg];
	}

	counsellor(int ID, int ASG, string NAME)
	{
		id = ID;
		name = NAME;
		asg = ASG;
		assign_std = new int[asg];
	}
	void set_counsellor_id(int ID)
	{
		id = ID;
	}
	int get_asg()
	{
		return asg;
	}
	string get_name()
	{
		return name;
	}
	int get_assign(int i)
	{
		return assign_std[i];
	}
	void set_student_ns(int n)
	{
		ns = n;
	}
	int set_student_ns()
	{
		return ns;
	}


	//###########################################################################//
	friend  istream& operator >> (istream& in, counsellor& cns);
	friend  ostream& operator << (ostream& out, counsellor& cns);
	counsellor operator += (const  student& STD); // assign student to counsellor//
	counsellor operator -= (const  student& STD);// remove student to counsellor//
	bool  operator == (const counsellor cns);
	bool  operator < (const counsellor cns);
	bool  operator > (const counsellor cns);

	/*~counsellor()
	{
		delete[]assign_std;
	}
	*/

};