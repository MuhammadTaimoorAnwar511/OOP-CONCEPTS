#include<iostream>
#include"2Header.h"
using namespace std;

int main()
{
	matrix m1(3, 3), m2(3, 3), m3(3,3), m4(m3);
	
	int opt;
	cin >> m1;

	cout << endl;
	cin >> m2;
	cout << endl;
	cin >> m3;
	cout << endl;
	cout << "\n=======================\n";
	do
	{
		do
		{
			cout << " Enter option (1 to 11)\n";
			cout << "1]Display.\n2] m1+m2-m3 \n3] sub m2-m1 \n4] m1*m2 \n5] m1+=2 \n6] m1-=2 \n7] m3*=10 \n8] m3/=2 \n9]m1==m2 \n10]m1=m2\n11] m5 = m1(3,3) \n= ";
			cin >> opt;
		} while (opt <= 0 || opt > 11);

		switch (opt)
		{

		case 1:
			cout << " matrix 1 elements values\n";
			cout << m1;
			cout << endl;
			cout << " matrix 2 elements values\n";
			cout << m2;
			cout << " matrix 3 elements values\n";
			cout << m3;
			cout << "\n=======================\n";
			cout << "\n==========\n";
			cout << "sum and sub  m1 + m2 - m3\n";
			break;

		case 2:
			m4 = m1 + m2 - m3;
			cout << m4;
			cout << "\n============\n";
			break;

		case 3:
			cout << "sub  m2-m1 \n";
			cout << m2 - m1;
			cout << "\n============   m1*m2\n";
			break;

		case 4:
			cout << "multi\n";
			cout << m1 * m2;
			cout << "\n============\n";
			break;

		case 5:
			m1 += 2;
			cout << "\n +=2 operator function\n";
			cout << m1;
			cout << "\n============\n";
			break;

		case 6:
			m1 -= 2;
			cout << "\n -=2  operator function\n";
			cout << m1;
			cout << "\n============\n";
			break;

		case 7:
			m3 *= 10;
			cout << "\n *=10  operator function\n";
			cout << m3;
			cout << "\n============\n";
			break;

		case 8:
			m3 /= 2;
			cout << "\n /=2  operator function\n";
			cout << m3;
			cout << "\n==============\n";
			break;

		case 9:
			cout << "\n ==  operator function  m1 == m2\n";
			m1 == m2;
			cout << "\n==========\n";
			break;

		case 10:
			cout << "\n =   operator function  m1=m2\n";
			m1 = m2;
			cout << m1;
			cout << endl;
			cout << "\n==============\n";
			break;

		case 11:
			cout << "\n m5 = m1(3,3)\n";
			matrix m5 = m1;
			cout << m5;
			break;

		}

		do
		{
			cout << "\n=================\n";
			cout << "Select option\n ";
			cout << "press 0 to exit\npress 1 to run program again \n= ";
			cin >> opt;
		} while (opt < 0 || opt > 1);

	} while (opt == 1);

	return 0;
}