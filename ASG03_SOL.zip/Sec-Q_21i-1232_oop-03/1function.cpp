#include<iostream>
#include"1Header.h"
using namespace std;
//-----------------------------------------------------------//
 void menu  (extented_character &e1, extented_character &e2, extented_character &e3)
{
	 char charac;
	int option;
	cout << "\n======================\n";

	do
	{
		do
		{
			cout << "Select option\n";
			cout << "1] + operator\n2] - operator\n3] = operator\n4] == operator\n5] != operator\n6] <= operator\n7] >= operator\n8] < operator\n9] > operator\n10] ++ operator\n11] ++ operator\n12] -- opertor\n13] -- operator\n14] operator int ()\n15] operator short ()\n16]Enter range of number \n= ";
			cout << "= ";
			cin >> option;
		} while (option<=0 || option>16);
		
		switch (option)
		{
		case 1:
			cout << "\ne1+e2\n";
			e3 = e1 + e2;
			cout << e3;
			break;
		case 2:
			cout << "\ne1-e2\n";
			e3 = e1 - e2;
			cout << e3;
			break;
		case 3:
			cout << "\ne1=e2\n";
			e1=e2;
			cout << e1;
			break;
		case 4:
			cout << "\ne1==e2\n";
			e1==e2;
			break;
		case 5:
			cout << "\ne1!=e2\n";
			e1!= e2;
			break;
		case 6:
			cout << "\ne1<=e2\n";
			e1<=e2;
			break;
		case 7:
			cout << "\ne1>=e2\n";
			e1 >= e2;
			break;
		case 8:
			cout << "\ne1<e2\n";
			e1 < e2;
			break;
		case 9:
			cout << "\ne1>e2\n";
			e1 > e2;
			break;
		case 10:
			cout << "\n++e1\n";
			++e1;
			break;
		case 11:
			cout << "\ne1++\n";
			 e1++;
			break;
		case 12:
			cout << "\n--e1\n";
			--e1;
			break;
		case 13:
			cout << "\ne1--\n";
			e1--;
			break;
		case 14:
			cout << "\nint(e1)\n";
			cout << int(e1);
			break;
		case 15:
			cout << "\nshort(e1)\n";
			cout << short(e1);
			break;
		case 16:
			int n1, n2;
			cout << "\nEnter range\n";
			cout << "\nEnter First number \n= ";
			cin >> n1;
			cout << "\nEnter First Second number\n= ";
			cin >> n2;
			e3(n1, n2);
			break;
		}
		do
		{
			cout << "\n=================\n";
			cout << "Select option\n ";
			cout << "Press 0 to exit\nPress 1 to run program again \n= ";
			cin >> option;
		} while (option < 0 || option > 1);
	} while (option==1);
}
 //----------------------------------------------------------//
 //---------------------------------------------------------//
istream& operator >> (istream& in, extented_character& c)
{
	
	in >> c.ch;
		
	return in;
}
ostream& operator << (ostream& out, extented_character&  c)
{

    out<< c.ch;

	return out;
}
//-----------------------------------------------------------//
extented_character extented_character:: operator  + (const  extented_character& c)
{
	extented_character temp;
	temp.ch = ch + c.ch;
	return temp;
}
extented_character extented_character:: operator  - (const  extented_character& c)
{
	extented_character temp;
	temp.ch = ch - c.ch;
	return temp;
}
extented_character extented_character:: operator  = (const  extented_character& c)
{
	extented_character temp;
	temp.ch =c.ch;
	ch = temp.ch;
	return temp;
}

bool extented_character ::  operator == (const extented_character& c)
{
     bool status;

	 if (ch == c.ch)
	{
		status = true;
		cout << "STATUS TRUE = ";
	}
	else
	{
		status = false;
		cout << "STATUS FALSE = ";
	}
	
	cout << status;
	return status;
}
bool extented_character ::  operator != (const extented_character& c)
{
	bool status;
	if (ch != c.ch)
	{
		status = true;
		cout << "STATUS TRUE = ";
	}
	else
	{
		status = false;
		cout << "STATUS FALSE = ";
	}

	cout << status;
	return status;
}
bool extented_character ::  operator <= (const extented_character& c)
{
	bool status;
	if (ch <= c.ch)
	{
		status = true;
		cout << "STATUS TRUE = ";
	}
	else
	{
		status = false;
		cout << "STATUS FALSE = ";
	}

	cout << status;
	return status;
}
bool extented_character ::  operator >= (const extented_character& c)
{
	bool status;
	if (ch >= c.ch)
	{
		status = true;
		cout << "STATUS TRUE = ";
	}
	else
	{
		status = false;
		cout << "STATUS FALSE = ";
	}

	cout << status;
	return status;
}
bool extented_character ::  operator < (const extented_character& c)
{
	bool status;
	if (ch < c.ch)
	{
		status = true;
		cout << "STATUS TRUE = ";
	}
	else
	{
		status = false;
		cout << "STATUS FALSE = ";
	}

	cout << status;
	return status;
}
bool extented_character ::  operator > (const extented_character& c)
{
	bool status;
	if (ch > c.ch)
	{
		status = true;
		cout << "STATUS TRUE = ";
	}
	else
	{
		status = false;
		cout << "STATUS FALSE = ";
	}

	cout << status;
	return status;
}
//-----------------------------------------------------------//
extented_character& extented_character:: operator ++ ()
{
	extented_character temp;
	
	(int)++ch;
	temp.ch =(int)ch;
	
cout << temp.ch << endl;
	return temp;
}
extented_character& extented_character:: operator ++ (int)
{

	extented_character temp;
	(int)ch++;
	temp.ch = (int)ch;
	cout << temp.ch << endl;
	return temp;
}
extented_character& extented_character:: operator -- ()
{
	extented_character temp;

	(int)--ch;
	temp.ch = (int)ch;

	cout << temp.ch << endl;
	return temp;
}
extented_character& extented_character:: operator -- (int)
{
	extented_character temp;
	(int)ch--;
	temp.ch = (int)ch;
	cout << temp.ch << endl;
	return temp;
}
//-----------------------------------------------------------//
extented_character :: operator int()
{
	return   (int)ch;
}
extented_character :: operator short()
{
	return   (short)ch;
}
extented_character& extented_character :: operator () (int  a,int b)
{
	extented_character  t=1;
	if (a >= 97 && b <= 122)
	{
		cout << "IT is range of small alphabets \n";
	}
	else if (a >= 65 && b <= 90)
	{
		cout << "IT is range of CAPITAL  ALPHABETS \n";
	}
	else if (a >= 48 && b <= 57)
	{
		cout << "IT is range of Numbers 0 to 9 \n";
	}
	else
	{
		cout << " not specific \n";
	}
	return t;
}
//-----------------------------------------------------------//

