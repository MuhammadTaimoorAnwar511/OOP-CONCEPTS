#include<iostream>
#include"1Header.h"
using namespace std;

int main()
{
	int option;
	char ch;
	extented_character e1,e2,e3;

	cout << " Enter E1 character  \n= ";
	cin >> e1;
	cout << " Enter E2 character \n= ";
	cin >> ch;
	e2.set_char(ch);

	menu(e1,e2,e3);
	return 0;
}
 
