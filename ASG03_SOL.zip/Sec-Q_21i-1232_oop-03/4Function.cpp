#include<iostream>
#include<string>
#include<ctime>
#include"4Header.h"
using namespace std;

//====================================================================================//

istream& operator >> (istream& in, student& STD)
{
	int random;
	STD.name = 'a' + rand() % 26;
	STD.batch = 2021;
	random = rand() % 4;
	if (random == 0)
	{
		STD.degree = " SoftWare ";
	}
	else if (random == 1)
	{
		STD.degree = " Artificail Intelligence ";
	}
	else if (random == 2)
	{
		STD.degree = " Computer Software ";
	}
	else if (random == 3)
	{
		STD.degree = " English ";
	}
	random = rand() % 5;
	if (random == 0)
	{
		STD.gpa = 3.6;
	}
	else if (random == 1)
	{
		STD.gpa = 3.2;
	}
	else if (random == 2)
	{
		STD.gpa = 2.5;
	}
	else if (random == 3)
	{
		STD.gpa = 2.3;
	}
	else if (random == 4)
	{
		STD.gpa = 3.9;
	}
	random = rand() % 3;

	if (random == 0)
	{
		STD.birth = "10/JAN/2000";
	}
	else  if (random == 1)
	{
		STD.birth = "1/FEB/1999";
	}
	else  if (random == 2)
	{
		STD.birth = "15/DEC/2002";
	}
	else  if (random == 3)
	{
		STD.birth = "20/SEPT/2005";
	}

	return in;
}

ostream& operator << (ostream& out, student& STD)
{
	out << "ROLL # " << STD.roll_number << endl;
	out << "NAME   " << STD.name << endl;
	out << "BATCH  " << STD.batch << endl;
	out << "GPA    " << STD.gpa << endl;
	out << "DEGREE " << STD.degree << endl;
	out << "BIRTH  " << STD.birth << endl;
	cout << "============================\n\n\n";
	return out;
}

//====================================================================================//
istream& operator >> (istream& in, counsellor& cns)
{
	int index;
	cout << "Enter Counsellor name \n= ";
	in >> cns.name;
	do
	{
		cout << " Enter number of student assignes to counselor (1 to " << cns.ns << ")\n= ";
		in >> cns.asg;

	} while (cns.asg <= 0 || cns.asg > cns.ns);

	cns.assign_std = new int[cns.asg];
	for (int r = 0;r < cns.asg;r++)
	{
		cns.assign_std[r] = 0;
	}
	return in;
}

ostream& operator << (ostream& out, counsellor& cns)
{
	cout << "\nCounsellor ID \n=   ";
	out << cns.id;
	cout << "\nCounsellor name \n= ";
	out << cns.name;
	cout << "\nNumber of student assignes to counselor\n= ";
	out << cns.asg;
	cout << endl;
	cout << "\nCounsellor name \n= ";
	out << cns.name;
	for (int r = 0;r < cns.asg;r++)
	{
		cout << "\nstudent roll # = ";
		out << cns.assign_std[r] << "\n";
	}

	cout << "\n=======================\n\n";
	return out;
}

//====================================================================================//
counsellor counsellor :: operator  += (const  student& STD)
{
	counsellor t;
	int roll;
	int sc = 1;//student count
	cout << " Counsellor name " << name << endl;

	for (int r = 0;r < asg;r++)
	{
		cout << " Assign First Student = " << sc << endl;
		do
		{
			cout << "Enter student roll #( 0 to " << ns - 1 << " ) = ";
			cin >> roll;
		} while (roll < 0 || roll >= ns);

		assign_std[r] = roll;
		++sc;
	}

	return t;
}
counsellor counsellor :: operator  -= (const  student& STD)
{
	counsellor t;
	int roll;
	int sc = 1;//student count//
	int del;
	cout << " Counsellor name " << name << endl;
	cout << "Enter number of student you want to delete ( 1 to " << asg << " ) = ";
	cin >> del;
	for (int d = 0;d < del;d++)
	{
		cout << " Delete  Student = " << sc << endl;
		do
		{ 

			cout << "Enter student roll # ( ";
			for(int k=0;k<asg;k++)
			{
				cout << assign_std[k] << " / ";
			}
			cout << " ) you want to delete \n ";
			cin >> roll;
		} while (roll < 0 || roll >= ns);

		for (int i = 0;i < asg;i++)
		{
			
			if (assign_std[i] == roll)
			{
				assign_std[i] = 0;
			}
		}
		++sc;
	}

	return t;
}


//-----------------------------------------------------------------------------------//
//------------------------------------------------------------------------------------//
bool counsellor::  operator == (const counsellor cns)
{
	bool status;

	if (asg == cns.asg)
	{
		cout << "TRUE = ";
		status = 1;
	}
	else
	{
		cout << "FALSE  = ";
		status = 0;
	}
	cout << status << endl;
	return status;
}

bool counsellor::  operator < (const counsellor cns)
{
	bool status;

	if (asg < cns.asg)
	{
		cout << "TRUE = ";
		status = 1;
	}
	else
	{
		cout << "FALSE  = ";
		status = 0;
	}
	cout << status << endl;
	return status;
}

bool counsellor::  operator > (const counsellor cns)
{
	bool status;

	if (asg > cns.asg)
	{
		cout << "TRUE = ";
		status = 1;
	}
	else
	{
		cout << "FALSE  = ";
		status = 0;
	}
	cout << status << endl;
	return status;
}
//-----------------------------------------------------------------------------------//
//------------------------------------------------------------------------------------//
