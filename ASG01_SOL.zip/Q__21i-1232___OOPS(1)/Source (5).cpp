#include<iostream>
#include<iomanip>
#include<ctime>
#include<string>
using namespace std;

struct task
{
	int id;
	int dur;       // duration of task //
	float s_Time; //start time of each task
	string dep;    
	float skill_ID;
};

//----------------//
void add_task(int n ,task list[]);
void duration(int n, task list[]);
void specific(int n, task list[]);
void dep(int n, task list[]);
//----------------//

void add_task(int n, task list[])
{
	int k = 0;
	int j = 0;
	int s = 0;


	for (int i = 0;i < n;i++)
	{
		s = rand() % 3;
		list[i].id = k++;
		list[i].dur = rand() % 7;
		list[i].s_Time = rand() % 10;
		list[0].s_Time = 0;
		if (s == 0)
		{
			list[i].skill_ID = 0;
		}
		else if (s == 1)
		{
			list[i].skill_ID = 1;
		}
		else
		{
			list[i].skill_ID = 0.5;
		}
	}
	cout << "ID" << setw(20) << "DURATION" << setw(20) << "TIME" << setw(20) << "skill\n";
	for (int i = 0;i < n;i++)
	{
		cout << list[i].id << setw(20) << list[i].dur << setw(20) << list[i].s_Time << setw(20) << list[i].skill_ID;
		cout << endl;
	}
}
void duration(int n, task list[])
{
	for(int i=0;i<n;i++)
	{
		cout << "\nenter duration of TASK " << (i+1)<< endl;
		cin >> list[i].dur;
	}
}
void specific(int n, task list[])
{
	int i = 0;
	do 
	{
		cout << "enter task number to change specific duration  \n";
		cin >> i;
	} while (i <0 || i >=n);

	cin >> list[i].dur;
}
void dep(int n, task list[])
{
	int f, l;
	for (int i = 0;i < n;i++)
	{
		f = rand() % n;
		l = rand() % n;
		list[i].dep=f;
		cout << " DEPEND ON ";
		list[i].dep = l;
		cout << endl;
	}
}
int main()
{
	srand(time(NULL));
	int n;
	int r;
	cout << "enter number of task \n";
	cin >> n;
	cout << "enter number of RESOURCES \n";
	cin >> r;
	task* list = new task[n];

	//-------------------//
	add_task(n,list);
	duration(n,list);
	specific(n,list);
	dep(n,list);
	//---------------------//
	cout << "ID" << setw(20) << "DURATION" << setw(20) << "TIME" << setw(20) << "skill\n";
	for (int i = 0;i < n;i++)
	{
		cout << list[i].id << setw(20) << list[i].dur << setw(20) << list[i].s_Time << setw(20) << list[i].skill_ID;
		cout << endl;
	}
	//--------------------//
	delete[] list;
	return 0;
}