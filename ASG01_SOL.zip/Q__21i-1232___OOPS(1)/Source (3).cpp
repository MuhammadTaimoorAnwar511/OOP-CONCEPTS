#include<iostream>
#include<iomanip>
#include<string>
using namespace std;


struct temp
{
	int emp_ID;
	string  emp_Name;
	double Sales;
};
	struct Sales_Person 
	{
	int emp_ID;
	string  emp_Name;
	double Sales;
	};
	struct Salary 
	{
	int fixedSalary;   //Rs. 15000
	double comission; //2% of sale price of all sales
	double total_salary;
	};
	struct Customer
	{
		int cust_No;
		string C_Gender;
		int age;
	};
	struct FoodItem
	{
		int id;       
		string itemName;
		int price;
		int unisale;

	};
	struct salesData 
	{
		Customer c;
		int itemOrdered;
		FoodItem f;
		Sales_Person s;
		int t_sale;
	};
	//-------------------------------//
	void random(salesData& totaldata ,Customer custom[], FoodItem menu[], Sales_Person salesman[]);
	void totalsale(salesData& totaldata, FoodItem menu[],int noi,int oi);
	void indivisual(FoodItem menu[], Sales_Person salesman[], int noi, int oi,int sp);
	void sort(Sales_Person salesman[]);
	void commission(Sales_Person salesman[],Salary sall[]);
	void total_salory(Sales_Person salesman[], Salary sall[]);
	void sale_per_price(FoodItem menu[], int noi, int oi);
	//------------------------------//
int main()
{
	srand(time(NULL));
	int g;
	int i = 0;
	int id = 0;
	Customer custom[25];
	FoodItem menu[10];
	Sales_Person salesman[3];
	salesData totaldata;
	Salary  sall[3];
	while (i < 25)
	{
			custom[i].cust_No = id++;
			custom[i].age = (rand() % 60)+1;
			g = rand() % 2;
			if (g == 0)
			{
				custom[i].C_Gender = "FEMALE";
			}
			else
			{
				custom[i].C_Gender = "MALE";
			}

		i++;
	}
	i = 0;
	id = 0;
	while(i<3)
	{
		salesman[i].emp_ID = id++;
		salesman[i].Sales = 0;
		i++;
	}

	salesman[0].emp_Name = "JHON";
	salesman[1].emp_Name = "BOBE";
	salesman[2].emp_Name = "LUCE";
	
	i = 0;
	id = 0;
	while (i<10)
	{
		menu[i].id = id++;
		menu[i].unisale = 0;
		i++;
	}
	
	menu[0].itemName = "BURGURE";
	menu[1].itemName = "PIZZA";
	menu[2].itemName = "SANDWITCH";
	menu[3].itemName = "ROLL PRATHA";
	menu[4].itemName = "SHAWARMA";
	menu[5].itemName = "FRIES";
	menu[6].itemName = "SOMOSA";
	menu[7].itemName = "BIRYANI";
	menu[8].itemName = "COLD DRINK";
	menu[9].itemName = "COFFEE";

	menu[0].price = 200;
	menu[1].price = 1000;
	menu[2].price = 100;
	menu[3].price = 180;
	menu[4].price = 220;
	menu[5].price = 50;
	menu[6].price = 10;
	menu[7].price = 120;
	menu[8].price = 50;
	menu[9].price = 30;

//-------------------------------------------//
	cout << "------------------------------------------------------------\n";
	cout << setw(42) <<" CUSTOMERS \n";
	cout<<setw(20)<< "ID" << setw(20) << "AGE" << setw(22) << "GENDER\n\n";
	i = 0;
	while(i<25)
	{
			cout << setw(20);
			cout << custom[i].cust_No << setw(20);
			cout << custom[i].age << setw(20);
			cout << custom[i].C_Gender << setw(20);
			cout << endl;
		i++;
	}
	cout << "------------------------------------------------------------\n";
	cout << setw(35) << " MENU \n";
	cout <<setw(20) <<"ID"<< setw(20)<<"ITEAMS"<<setw(22)<<"PRICE\n\n";
	i = 0;
	while (i < 10)
	{
			cout << setw(20);
			cout << menu[i].id;
			cout << setw(20);
			cout << menu[i].itemName;
			cout << setw(20);
			cout << menu[i].price;
			cout << endl;
			i++;
	}
	cout << "------------------------------------------------------------\n";
	

//-------------------------------------------//
//--------------function call-------------//
 random(totaldata,custom,menu,salesman);
//-----------------------------------------//

 //--------------------OUT PUT-------------//

 cout <<"TOTAL SALE ARE " << totaldata.t_sale << " RS";
 cout << "\n---------------------sale----------------\n";
 
 cout << setw(20)<<"employ name "<<setw(20)<<"sale\n";
 i = 0;
 while (i<3)
 {
		 cout << setw(15);
		 cout << salesman[i].emp_Name << setw(25) << salesman[i].Sales << "\n";
		 i++;
 }
 cout << "\n--------------------sorted---------------\n";
 //------------//
 sort(salesman);
 //-------------// 
 cout << setw(20) << "employ name " << setw(20) << "sale\n";
 i = 0;
 while (i < 3)
 {
		 cout << setw(15);
		 cout << salesman[i].emp_Name << setw(25) << salesman[i].Sales << "\n"; 
		 i++;
 }
 cout << "\n----------------------------------------\n";

 //---------------//
 commission(salesman, sall);
 total_salory( salesman,sall);
 //--------------//
 cout << setw(20)<<" ITEAM "<<setw(20)<<" sale per ITEM \n";
 i = 0;
 while (i < 10)
 {
cout << setw(20) << menu[i].itemName << setw(20) << menu[i].unisale << " RS" << "\n";
	 i++;
 }
	return 0;
}

void random(salesData &totaldata,Customer custom[], FoodItem menu[], Sales_Person salesman[])
{
	int c;    // random customer        //
	int noi; // random  number of items//
	int oi; // random order iteam     //
	int sp;// random  sales person   //
	totaldata.t_sale = 0;
	int i = 0;
	while (i < 30)
	{
			noi = (rand() % 12) + 1;
			oi = rand() % 10;
			sp = rand() % 3;
			totalsale(totaldata, menu, noi, oi);
			indivisual(menu, salesman, noi, oi, sp);
			sale_per_price(menu, noi, oi);
			i++;
	}
}

void totalsale(salesData &totaldata, FoodItem menu[],int noi,int oi)
{
	int t=0;
	t = noi * menu[oi].price;
	totaldata.t_sale = totaldata.t_sale + t;
}

void indivisual(FoodItem menu[], Sales_Person salesman[], int noi, int oi,int sp)
{  
	salesman[sp].Sales = salesman[sp].Sales + (menu[oi].price*noi);
}

void sort(Sales_Person salesman[])
{
	int min;
	temp swap;
	for (int i = 0;i < 3;i++)
	{
		for (int j = i + 1;j < 3;j++)
		{
			if (salesman[i].Sales > salesman[j].Sales)
			{
				swap.emp_ID = salesman[i].emp_ID;
				swap.emp_Name= salesman[i].emp_Name;
				swap.Sales= salesman[i].Sales;

				salesman[i].emp_ID = salesman[j].emp_ID;
				salesman[i].emp_Name = salesman[j].emp_Name;
				salesman[i].Sales = salesman[j].Sales;
				
				salesman[j].emp_ID = swap.emp_ID;
				salesman[j].emp_Name = swap.emp_Name;
				salesman[j].Sales = swap.Sales;
			}
		}
	}
}
void commission(Sales_Person salesman[], Salary sall[])
{
	cout << "\n---------------------------------------------------------\n";
	cout << setw(20) << "employ name " << setw(20) << "sale" << setw(20) << "comission\n";
	int i = 0;
	while (i < 3)
	{
			sall[i].comission = (2 * salesman[i].Sales) / 100;
			sall[i].total_salary = 15000 + sall[i].comission;
			cout << setw(15);
			cout << salesman[i].emp_Name << setw(25) << salesman[i].Sales << setw(20) << sall[i].comission << " RS" << "\n";
			i++;
	}
	cout << "\n----------------------------------------------------------\n";
}
void total_salory(Sales_Person salesman[], Salary sall[])
{
	double pay=0;
	cout << "\n--------------------------------------------------------------------------------\n";
	cout << setw(20) << "employ name " << setw(20) << "sale" << setw(20) << "comission"<<setw(20)<<" total salory"<<"\n";
	int i = 0;
	while (i < 3)
	{
			pay = sall[i].total_salary + pay;
			cout << setw(15);
			cout << salesman[i].emp_Name << setw(25) << salesman[i].Sales << setw(20) << sall[i].comission << " RS" << setw(20) << sall[i].total_salary << " RS" << "\n";
			i++;
	}
	cout << "\n owner has to pay " << pay << " RS \n";
	cout << "\n--------------------------------------------------------------------------------\n";
}
void sale_per_price(FoodItem menu[],int noi,int oi)
{
	int t;
	 t= (noi * menu[oi].price);
	 menu[oi].unisale = menu[oi].unisale + t;


}