#include<iostream>
#include <iomanip>
#include<string>
#include<time.h>
using namespace std;

struct playerinfo
{
	int sr;
	char name;
	string type;
	float batingavg;
	float batingstrike;
	float bowlingavg;
	float bowlingstrike;
	int value;
	int available;
};

struct teaminfo
{
	int rank;
	string name;
};

//playerinfo* batsman = new playerinfo[no_bats];
//playerinfo* bowlman = new playerinfo[no_bowl];
//playerinfo* alrman = new playerinfo[no_alr];
//------------------------------------//
void draft(playerinfo* players, int R);
void sorting(playerinfo* players, int R, playerinfo* batsman, int no_bats, playerinfo* bowlman, int no_bowl, playerinfo* alrman, int no_alr, int rowbat, int rowbal, int rowalr);
void teams(teaminfo* team, int R);
void pick(teaminfo* team, int NT, playerinfo* batsman, int no_bats, playerinfo* bowlman, int no_bowl, playerinfo* alrman, int no_alr);
void selection(teaminfo* team, int NT, playerinfo* batsman, int no_bats, playerinfo* bowlman, int no_bowl, playerinfo* alrman, int no_alr);
//-----------------------------------//

//----------------------------------//
void draft(playerinfo* players, int  R)
{
	//-----------------------------------//
	cout << setw(5);
	cout << "serial #";
	cout << setw(20);
	cout << "name ";
	cout << setw(20);
	cout << "type";
	cout << setw(20);
	cout << "bating avg";
	cout << setw(20);
	cout << "bating strike ";
	cout << setw(20);
	cout << "bowling avg";
	cout << setw(20);
	cout << "bowling strkike";
	cout << setw(20);
	cout << "value";
	cout << setw(20);
	cout << "available";
	cout << setw(20);
	cout << endl;
	//-----------------------------------//
	for (int r = 0;r < R;r++)
	{
		cout << setw(20) << left;
		cout << players[r].sr;
		cout << setw(20) << left;
		cout << players[r].name;
		cout << setw(20) << left;
		cout << players[r].type;
		cout << setw(20) << left;
		cout << players[r].batingavg;
		cout << setw(20) << left;
		cout << players[r].batingstrike;
		cout << setw(20) << left;
		cout << players[r].bowlingavg;
		cout << setw(20) << left;
		cout << players[r].bowlingstrike;
		cout << setw(20) << left;
		cout << players[r].value;
		cout << setw(20) << left;
		cout << players[r].available;
		cout << setw(20) << left;
		cout << endl;
	}
}
//----------------------------------------------//
void sorting(playerinfo* players, int R, playerinfo* batsman, int no_bats, playerinfo* bowlman, int no_bowl, playerinfo* alrman, int no_alr, int rowbat, int rowbal, int rowalr)
{
	teaminfo* team = new teaminfo[4];
	int ansr = 0;// all rounder new serial number //
	int bnsr = 0;//bowler new serial number //
	int batnsr = 0;//batman new serial number //
	//--------------------------------------------//
	cout << endl;
	cout << "number of batsmans = ";
	cout << no_bats;
	cout << endl;
	cout << "number of bowler = ";
	cout << no_bowl;
	cout << endl;
	cout << "number of alrounder = ";
	cout << no_alr;
	cout << endl;
	//--------------------------------------------//
	for (int r = 0;r < R;r++)
	{
		// copying alrounder //
		if (players[r].batingavg != -1 && players[r].bowlingavg != -1)
		{
			alrman[rowalr].sr = ansr;
			alrman[rowalr].name = players[r].name;
			alrman[rowalr].type = players[r].type;
			alrman[rowalr].batingavg = players[r].batingavg;
			alrman[rowalr].batingstrike = players[r].batingstrike;
			alrman[rowalr].bowlingavg = players[r].bowlingavg;
			alrman[rowalr].bowlingstrike = players[r].bowlingstrike;
			alrman[rowalr].value = players[r].value;
			alrman[rowalr].available = players[r].available;
			++rowalr;
			++ansr;
		}
		// copying batsman //
		else if (players[r].bowlingavg == -1)
		{
			batsman[rowbat].sr = batnsr;
			batsman[rowbat].name = players[r].name;
			batsman[rowbat].type = players[r].type;
			batsman[rowbat].batingavg = players[r].batingavg;
			batsman[rowbat].batingstrike = players[r].batingstrike;
			batsman[rowbat].bowlingavg = players[r].bowlingavg;
			batsman[rowbat].bowlingstrike = players[r].bowlingstrike;
			batsman[rowbat].value = players[r].value;
			batsman[rowbat].available = players[r].available;
			++rowbat;
			++batnsr;
		}
		// coping bowler //
		else if (players[r].batingavg == -1)
		{
			bowlman[rowbal].sr = bnsr;
			bowlman[rowbal].name = players[r].name;
			bowlman[rowbal].type = players[r].type;
			bowlman[rowbal].batingavg = players[r].batingavg;
			bowlman[rowbal].batingstrike = players[r].batingstrike;
			bowlman[rowbal].bowlingavg = players[r].bowlingavg;
			bowlman[rowbal].bowlingstrike = players[r].bowlingstrike;
			bowlman[rowbal].value = players[r].value;
			bowlman[rowbal].available = players[r].available;
			++rowbal;
			++bnsr;

		}
	}
	cout << endl;
	//-----------------------------------------------------------//

	for (int r = 0;r < no_bats;r++)
	{
		cout << setw(20) << left;
		cout << batsman[r].sr;
		cout << setw(20) << left;
		cout << batsman[r].name;
		cout << setw(20) << left;
		cout << batsman[r].type;
		cout << setw(20) << left;
		cout << batsman[r].batingavg;
		cout << setw(20) << left;
		cout << batsman[r].batingstrike;
		cout << setw(20) << left;
		cout << batsman[r].bowlingavg;
		cout << setw(20) << left;
		cout << batsman[r].bowlingstrike;
		cout << setw(20) << left;
		cout << batsman[r].value;
		cout << setw(20) << left;
		cout << batsman[r].available;
		cout << endl;
	}
	//--------------------------------------------------------------//
	cout << endl;

	for (int r = 0;r < no_bowl;r++)
	{
		cout << setw(20) << left;
		cout << bowlman[r].sr;
		cout << setw(20) << left;
		cout << bowlman[r].name;
		cout << setw(20) << left;
		cout << bowlman[r].type;
		cout << setw(20) << left;
		cout << bowlman[r].batingavg;
		cout << setw(20) << left;
		cout << bowlman[r].batingstrike;
		cout << setw(20) << left;
		cout << bowlman[r].bowlingavg;
		cout << setw(20) << left;
		cout << bowlman[r].bowlingstrike;
		cout << setw(20) << left;
		cout << bowlman[r].value;
		cout << setw(20) << left;
		cout << bowlman[r].available;
		cout << endl;
	}
	//---------------------------------------------------------------//
	cout << endl;
	for (int r = 0;r < no_alr;r++)
	{
		cout << setw(20) << left;
		cout << alrman[r].sr;
		cout << setw(20) << left;
		cout << alrman[r].name;
		cout << setw(20) << left;
		cout << alrman[r].type;
		cout << setw(20) << left;
		cout << alrman[r].batingavg;
		cout << setw(20) << left;
		cout << alrman[r].batingstrike;
		cout << setw(20) << left;
		cout << alrman[r].bowlingavg;
		cout << setw(20) << left;
		cout << alrman[r].bowlingstrike;
		cout << setw(20) << left;
		cout << alrman[r].value;
		cout << setw(20) << left;
		cout << alrman[r].available;
		cout << endl;
	}
	//-------------//
  //teams(team, 4);
}

void teams(teaminfo* team, int R)
{

	int ranke;
	team[0].rank = 1;
	team[1].rank = 2;
	team[2].rank = 3;
	team[3].rank = 4;

	ranke = rand() % 2;

	if (ranke == 0)
	{
		team[0].name = "Pakistan";
		team[1].name = "India";
		team[2].name = "England";
		team[3].name = "Australia";
	}
	else if (ranke == 1)
	{
		team[3].name = "Pakistan";
		team[2].name = "India";
		team[1].name = "England";
		team[0].name = "Australia";
	}
	cout << endl;
	cout << setw(20);
	cout << "rank";
	cout << setw(20);
	cout << "teams";
	cout << endl;
	for (int r = 0;r < 4;r++)
	{
		cout << setw(20);
		cout << team[r].rank;
		cout << setw(20);
		cout << team[r].name;
		cout << endl;
	}

	cout << endl;
}
//----------------------------------------------------------------------------------------------//
void pick(teaminfo* team, int NT, playerinfo* batsman, int no_bats, playerinfo* bowlman, int no_bowl, playerinfo* alrman, int no_alr)
{
	//NT is equall to number of teams =4;//
	int want;//how many player team need after 16-want//
	//indicate no of player team can buy more after single selection //
	cout << endl;
	for (int r = 0;r < 4;r++)
	{
		do
		{
			want = 0;
			cout << "enter number of player  " << team[r].name << "  want to retain \n = ";
			cin >> want;

		} while (want < 7 || want >11);

		want = 16 - want;
		cout << "new player " << team[r].name << " can buy  = ";
		cout << want;

		for (int r = 0;r < want;r++)
		{
			cout << endl;
			selection(team, NT, batsman, no_bats, bowlman, no_bowl, alrman, no_alr);
		}
		cout << endl;
	}
}

void selection(teaminfo* team,int NT,playerinfo* batsman,int no_bats,playerinfo* bowlman,int no_bowl,playerinfo* alrman,int no_alr)
{
	
	int pres = 0;// to select specific player batsman/bowler/alrounder//
	int buy=0;    // to buy specific player //
	cout << "press 0 to select bowlers   \n = \n";
	cout << "press 1 to select batmans   \n = \n";
	cout << "press 2 to select alrounder \n = \n";
	cin >> pres;
	if (pres == 0)
	{
		cout << "list of bowlers \n";
		for (int r = 0;r < no_bowl;r++)
		{
			cout << setw(20) << left;
			cout << bowlman[r].sr;
			cout << setw(20) << left;
			cout << bowlman[r].name;
			cout << setw(20) << left;
			cout << bowlman[r].type;
			cout << setw(20) << left;
			cout << bowlman[r].batingavg;
			cout << setw(20) << left;
			cout << bowlman[r].batingstrike;
			cout << setw(20) << left;
			cout << bowlman[r].bowlingavg;
			cout << setw(20) << left;
			cout << bowlman[r].bowlingstrike;
			cout << setw(20) << left;
			cout << bowlman[r].value;
			cout << setw(20) << left;
			cout << bowlman[r].available;
			cout << endl;
		}
	}
	else if(pres==1)
	{
		cout << "list of batmans \n";
		for (int r = 0;r < no_bats;r++)
		{
			cout << setw(20) << left;
			cout << batsman[r].sr;
			cout << setw(20) << left;
			cout << batsman[r].name;
			cout << setw(20) << left;
			cout << batsman[r].type;
			cout << setw(20) << left;
			cout << batsman[r].batingavg;
			cout << setw(20) << left;
			cout << batsman[r].batingstrike;
			cout << setw(20) << left;
			cout << batsman[r].bowlingavg;
			cout << setw(20) << left;
			cout << batsman[r].bowlingstrike;
			cout << setw(20) << left;
			cout << batsman[r].value;
			cout << setw(20) << left;
			cout << batsman[r].available;
			cout << endl;
		}

	}
	else if (pres == 2)
	{
		cout << "list of alrounder \n";
		for (int r = 0;r < no_alr;r++)
		{
			cout << setw(20) << left;
			cout << alrman[r].sr;
			cout << setw(20) << left;
			cout << alrman[r].name;
			cout << setw(20) << left;
			cout << alrman[r].type;
			cout << setw(20) << left;
			cout << alrman[r].batingavg;
			cout << setw(20) << left;
			cout << alrman[r].batingstrike;
			cout << setw(20) << left;
			cout << alrman[r].bowlingavg;
			cout << setw(20) << left;
			cout << alrman[r].bowlingstrike;
			cout << setw(20) << left;
			cout << alrman[r].value;
			cout << setw(20) << left;
			cout << alrman[r].available;
			cout << endl;
		}

	}

	if (pres == 0)
	{
		cout << "type SR number to select bowler \n = ";
		cin >> buy;

		if (bowlman[buy].available == 1)
		{
			cout << "you bought the BOWLER succesfully\n\n ";
			bowlman[buy].available = 0;

		}
		else if (bowlman[buy].available == 0)
		{
			cout << "BOWLER is already sold \n\n";
		}
	}

	else if (pres == 1)
	{
		cout << "type SR number to select batmans \n = ";
		cin >> buy;
		if (batsman[buy].available == 1)
		{
			cout << "you bought the BATMAN succesfully\n\n ";
			batsman[buy].available = 0;

		}
		else if (batsman[buy].available == 0)
		{
			cout << "BATMAN is already sold \n\n";
		}
	}

	else if (pres==2)
	{
		cout << "type SR number to select ALLROUNDER \n = ";
		cin >> buy;
		if (alrman[buy].available == 1)
		{
			cout << "you bought the ALLROUNDER succesfully\n\n ";
			alrman[buy].available = 0;

		}
		else if (alrman[buy].available == 0)
		{
			cout << "ALLROUNDER is already sold \n\n";
		}
	}
}

//---------------------------------------------------------------------------------------------------------//
//---------------------------------------------------------------------------------------------------------//
int main()
{
	srand(time(NULL));
	int serial = 0; // serial number of player       //
	int R = 0;     // numbers of rows               //
	int C = 9;    //numbers of columns             //
	int ROW = 0; //number of rows of sorting array//
	int n = 0;  // generate random number which help generte alphabets//
	char alph; // generate random                   //
	float fb; // genrating random float for batman //
	float inc = 0.1; //help generating floating number for batmans//
	int   typ;      // help to genrate batman/bowler/allrounder  //
	int v = 100000;//value of player //
	cout << "enter number of player for draft \n= ";
	cin >> R;
	//-----------------dynamic memory ---------------------//
	playerinfo* players = new playerinfo[R]; // player information //
	teaminfo* team = new teaminfo[4];         // for teams          //
	//-------------------------------------------------------------------------//
	//-------------------------------------data for draft---------------------//
	for (int r = 0;r < R;r++)
	{
		++serial;
		// serial number //;
		players[r].sr = serial;
		n = rand() % 26;
		alph = 'a' + n;
		// name //
		players[r].name = alph;
		typ = rand() % 3;
		// type //
		if (typ == 0)
		{
			players[r].type = "batman";
		}
		else if (typ == 1)
		{
			players[r].type = "bowler";
		}
		else
		{
			players[r].type = "alrounder";
		}
		// bating average //
		if (typ == 1)
		{
			players[r].batingavg = -1;
		}
		else
		{
			inc = 0.1;
			inc = inc + inc;
			fb = rand() % 20;
			fb = fb + inc;
			players[r].batingavg = fb;
		}
		// bating strike  //
		if (typ == 1)
		{
			players[r].batingstrike = -1;
		}
		else
		{
			inc = 0.1;
			inc = inc + inc;
			fb = rand() % 20;
			fb = fb + inc;
			players[r].batingstrike = fb;
		}
		//bowling average//
		if (typ == 0)
		{
			players[r].bowlingavg = -1;
		}
		else
		{
			inc = 0.1;
			inc = inc + inc;
			fb = rand() % 20;
			fb = fb + inc;
			players[r].bowlingavg = fb;
		}
		// bowling strike  //
		if (typ == 0)
		{
			players[r].bowlingstrike = -1;
		}
		else
		{
			inc = 0.1;
			fb = rand() % 20;
			fb = fb + inc;
			players[r].bowlingstrike = fb;
		}
		// player value //
		n = rand() % 2;
		if (n == 0)
		{
			v = v + 20000;
			players[r].value = v;
		}
		else
		{
			v = v + 30000;
			players[r].value = v;
		}
		// availability  //
		players[r].available = 1;
	}

	//-------------------------------------------------------------------------//
   //-------------------------------------------------------------------------//
  //-------------------------------------------------------------------------//


 //---------------------for sorting ---------------//
	int rowbat = 0;  // to controll  number of sortplayer for batsman       //
	int rowbal = 0; // to controll number of sortedplayer for bowler       // 
	int rowalr = 0;// to controll number of sortedplayer for allrounder   // 

	int no_bats = 0; // count number of bats            //
	int no_bowl = 0;// count number of bowler        //
	int no_alr = 0;//count number of allrounder     //

	// caluclating number of bats , bowler, allrounder for dynamic memory allocation // 
	for (int r = 0;r < R;r++)
	{
		if (players[r].bowlingavg == -1)
		{
			++no_bats;
		}
	}
	//----//
	for (int r = 0;r < R;r++)
	{
		if (players[r].batingavg == -1)
		{
			++no_bowl;
		}
	}
	//----//
	for (int r = 0;r < R;r++)
	{
		if (players[r].batingavg != -1 && players[r].bowlingavg != -1)
		{
			++no_alr;
		}
	}

	//-------------dynamic memory allocation for sorted--------------//
	playerinfo* batsman = new playerinfo[no_bats];
	playerinfo* bowlman = new playerinfo[no_bowl];
	playerinfo* alrman = new playerinfo[no_alr];
	//-------------------------------------------------------------------------------//

										//----//
	//------------------------------function calls---------------------------------//
	draft(players, R);
	sorting(players, R, batsman, no_bats, bowlman, no_bowl, alrman, no_alr, rowbat, rowbal, rowalr);
	teams(team, 4);
	pick(team, 4, batsman, no_bats, bowlman, no_bowl, alrman, no_alr);
	//--------------------------------------------------------------------------------------------------//
	//--------------------------------------total number of player after sold-------------------------//
	cout <<" total number of player after sold";
	cout << endl;
	for (int r = 0;r < no_bats;r++)
	{
		cout << setw(20) << left;
		cout << batsman[r].sr;
		cout << setw(20) << left;
		cout << batsman[r].name;
		cout << setw(20) << left;
		cout << batsman[r].type;
		cout << setw(20) << left;
		cout << batsman[r].batingavg;
		cout << setw(20) << left;
		cout << batsman[r].batingstrike;
		cout << setw(20) << left;
		cout << batsman[r].bowlingavg;
		cout << setw(20) << left;
		cout << batsman[r].bowlingstrike;
		cout << setw(20) << left;
		cout << batsman[r].value;
		cout << setw(20) << left;
		cout << batsman[r].available;
		cout << endl;
	}
	//--------------------------------------------------------------//
	cout << endl;

	for (int r = 0;r < no_bowl;r++)
	{
		cout << setw(20) << left;
		cout << bowlman[r].sr;
		cout << setw(20) << left;
		cout << bowlman[r].name;
		cout << setw(20) << left;
		cout << bowlman[r].type;
		cout << setw(20) << left;
		cout << bowlman[r].batingavg;
		cout << setw(20) << left;
		cout << bowlman[r].batingstrike;
		cout << setw(20) << left;
		cout << bowlman[r].bowlingavg;
		cout << setw(20) << left;
		cout << bowlman[r].bowlingstrike;
		cout << setw(20) << left;
		cout << bowlman[r].value;
		cout << setw(20) << left;
		cout << bowlman[r].available;
		cout << endl;
	}
	//---------------------------------------------------------------//
	cout << endl;
	for (int r = 0;r < no_alr;r++)
	{
		cout << setw(20) << left;
		cout << alrman[r].sr;
		cout << setw(20) << left;
		cout << alrman[r].name;
		cout << setw(20) << left;
		cout << alrman[r].type;
		cout << setw(20) << left;
		cout << alrman[r].batingavg;
		cout << setw(20) << left;
		cout << alrman[r].batingstrike;
		cout << setw(20) << left;
		cout << alrman[r].bowlingavg;
		cout << setw(20) << left;
		cout << alrman[r].bowlingstrike;
		cout << setw(20) << left;
		cout << alrman[r].value;
		cout << setw(20) << left;
		cout << alrman[r].available;
		cout << endl;
	}
	cout << endl;






   //-----deletion------//
	delete[] players;
	delete[] batsman;
	delete[] bowlman;
	delete[] alrman;
	delete[] team;
	//--------------//

	return 0;
}
