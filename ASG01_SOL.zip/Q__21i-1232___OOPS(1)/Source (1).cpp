#include<iostream>
#include<string>
#include<time.h>
#include<iomanip>
using namespace std;
//--------------------------------------//
struct city
{
	string city_name;  // name of cities//
};
struct customer
{
	int cust_id;     // customer id      //
	char  name;     // name of customer //
	int w_purchse; //weekly purchase   //
	int age;      // age              //
};
struct menu
{
	string flavor_name;// flavor of ice            //
	int flavor_id;    // flavr number             //
	int price[2];    // mini or family pack price//
};
struct iceoutlet
{
	int outlet_id;        // outlet unique id     //
	int topcust[10];// top customer of week //
	int topid[10];
	int revenu;         //total outlet sale     //
};

//---------------------------------//
               //--FUNCTION--//
void first(menu  flav[],customer custom[],iceoutlet outlet[]);
void order(menu  flav[],customer custom[], iceoutlet outlet[],int c,int row,int f,int p);
void topten(menu flav[],customer custom[], iceoutlet outlet[],int c,int row,int f,int p);
void outletrevenus(iceoutlet outlet[]);
void discount(customer custom[]);
//--------------------------------//
int main()
{
	srand(time(NULL));
	int c_id = 0;          // to create unique id for customer//	
	customer  custom[25]; // total number of customers       //
	iceoutlet outlet[50];// number of outlets               //
	city cityy[5];      //total number of city             //
	menu    flav[4];     
	int o_id = 100;    // to creat unique id for outlet  //
	 //----------------------initilaized----------------//	
	                          //---customers-----//
	for (int i = 0;i < 25;i++)
	{
		custom[i].cust_id = c_id++;
		custom[i].age = rand() % (80-10+1)+10;
		custom[i].name = (rand() % 26)+'a';
		custom[i].w_purchse = 0;
	}
	                         //genrating outlet id via increment //

	for (int c = 0;c <50;c++)
	{
		outlet[c].outlet_id = ++o_id;
	}

	for (int r = 0;r < 50;r++)
	{
		for (int c=0;c<10;c++)
		{
			outlet[r].topcust[c] = 0;
			outlet[r].topid[c] =0;
			outlet[r].revenu=0;
		}
	}

	                                    //--city names--//
	cityy[0].city_name = "RAWALPINDI";
	cityy[1].city_name = "ISLAMABAD ";
	cityy[2].city_name = "KARACHI   ";
	cityy[3].city_name = "LAHORE    ";
	cityy[4].city_name = "FASILABAD ";
	                                    //---MENU---//
		// initialized flavor //
	flav[0].flavor_name = { "Mango    " };
	flav[1].flavor_name = { "stabery  " };
	flav[2].flavor_name = { "chocolate" };
	flav[3].flavor_name = { "vanilla  " };

	flav[0].flavor_id = 1;
	flav[1].flavor_id = 2;
	flav[2].flavor_id = 3;
	flav[3].flavor_id = 4;

	flav[0].price[0] = 30;
	flav[0].price[1] = 120;
	flav[1].price[0] = 40;
	flav[1].price[1] = 130;
	flav[2].price[0] = 40;
	flav[2].price[1] = 130;
	flav[3].price[0] = 25;
	flav[3].price[1] = 110;
	//---------------------------------------//
	                                     //--customer--//
	                                  //---outlets and city---//
	cout<<"-----------------------------------------------------------------\n";
	cout << "CITY" << setw(30) << "OUTLET ID\n";
	
		cout << cityy[0].city_name << "      ";
		for (int c = 0;c < 10;c++)
		{
			cout << outlet[c].outlet_id << "  ";
			
		}
		cout << endl;
		cout << cityy[1].city_name << "      ";
		for (int c = 10;c < 20;c++)
		{
			cout << outlet[c].outlet_id << "  ";

		}
		cout << endl;
		cout << cityy[2].city_name << "      ";
		for (int c = 20;c < 30;c++)
		{
			cout << outlet[c].outlet_id << "  ";

		}
		cout << endl;
		cout << cityy[3].city_name << "      ";
		for (int c = 30;c < 40;c++)
		{
			cout << outlet[c].outlet_id << "  ";

		}
		cout << endl;
		cout << cityy[4].city_name << "      ";
		for (int c = 40;c < 50;c++)
		{
			cout << outlet[c].outlet_id << "  ";

		}
		cout << endl;
	
	cout << "-----------------------------------------------------------------\n";
	                                           //---MENU---//
	cout << setw(20) << "MENU\n";
	cout << "Id  FLAVOR          MINI   FAMILY PACK  \n";
	for (int i = 0;i < 4;i++)
	{
		cout << flav[i].flavor_id << "   " << flav[i].flavor_name << "        " << flav[i].price[0];
		cout << "     " << flav[i].price[1] << endl;
	}
	

	//----------------------------Function Calls---------------------//
	first(flav,custom, outlet);
	//-------------------------------------------------------------//
	cout << endl;
	cout << setw(60) << "WEEK PURCHASE of each customer  \n";
	cout << setw(20) << "name" << setw(20) << "ID" << setw(20) << "AGE"<<setw(25)<<"week purchase \n";
	for (int r=0;r<25;r++)
	{
		    cout << setw(20);
			cout << custom[r].name << setw(20);
			cout << custom[r].cust_id << setw(20);
			cout << custom[r].age << setw(20);
			cout << custom[r].w_purchse << setw(20);
			cout << endl;
	}
	cout << "--------------------------------------------------------------\n";
	cout << setw(60) << "top 10 customer  of each out let  \n";
	cout << "--------------------------------------------------------------\n";
	cout << "OUTLET" << setw(30) << "customer ID'S\n";
	for (int R = 0;R < 50;R++)
	{
		if (outlet[R].revenu != 0)// selecte specific resturant //
		{
		cout << outlet[R].outlet_id << "|    ";
				for (int r = 0;r < 10;r++)
				{
					{
						cout << outlet[R].topid[r] << "  ";
					}
				}
		 cout << endl;
		}
	}
	//----------------------------Function Calls---------------------//
	outletrevenus(outlet);
	discount(custom);
	//-------------------------------------------------------------//
	return 0;

}
void first(menu flav[],customer custom[], iceoutlet outlet[])
{
	
	int no_out = 50;         // number of out lets //
	int no_of_customers = 0;// controll number of customer each day//
	int day = 0;           // controll number of days //
	int f = 0;            // to select random flavour //
	int p = 0;           // to select random price 
	int c = 0;          // help to genrate random cusomer id //
	int row;           // row and col help to generate random outlet //

	while (day <= 7)
	{
		while (no_of_customers <= 80)
		{
			no_of_customers++;

			c = rand() % 25;
			row = rand() % 50;
			f = rand() % 4;
			p = rand() % 2;
		order(flav,custom,outlet,c,row,f,p);
		}
		day++;
		no_of_customers = 0;
	}
	//cout << endl;
	cout << "--------------------------------------------------------------------------------------\n";
}

void order(menu flav[],customer custom[], iceoutlet outlet[], int c, int row, int f, int p)
{
	int bought; // update week purchase //
	int reven ; // outlet revenue //
	bought = custom[c].w_purchse;
	custom[c].w_purchse = flav[f].price[p]+bought;
	outlet[row].revenu = outlet[row].revenu + flav[f].price[p];//custom[c].w_purchse;
    //------------------//
    topten(flav,custom,outlet,c,row,f,p);
  //-----------------//
}
void topten (menu flav[],customer custom[], iceoutlet outlet[],int c,int row,int f,int p)
{  
	int once=0;
	for (int up = 0;up < 10;up++)
	{
		if (custom[c].w_purchse >= outlet[row].topcust[up])// this is wrong //
		{
			if (once == 0)
			{
				outlet[row].topcust[up] = custom[c].w_purchse;
				outlet[row].topid[up] = custom[c].cust_id;
				++once;
			}
		}
		else
		{

		}		
	}
}

void outletrevenus(iceoutlet outlet[])
{

	cout << "-----------------------------------\n";
	cout << "outlet ID" << setw(20) << "REVENUE \n";
	for (int r = 0;r < 50;r++)
	{
		if (r == 0)
		{
			cout <<"RAWALPINDI\n";
		}
		else if (r == 10)
			{
				cout << "ISLAMABAD\n";
			}
		else if (r == 20)
		{
			cout << "KARACHI\n";
		}
		else if (r == 30)
		{
			cout << "LAHORE\n";
		}
		else if (r == 40)
		{
			cout << "FAISLABAD\n";
		}
		cout << outlet[r].outlet_id << setw(20) << outlet[r].revenu<<"\n";
	}
}
void discount(customer custom[])
{
	cout << "------------------------------------\n";
	cout << setw(30) << "Customer most likely to get discount \n";
	cout << "-----------------------------------------------------------------\n";
	cout << "ID" << setw(20) << "NAME" << setw(20) << "AGE"<<setw(20)<<"WEEK PURCHASE"<<"\n";
	for (int r = 0;r < 25;r++)
	{
		if (custom[r].w_purchse >= 2000)
		{
			cout << custom[r].cust_id << setw(20) << custom[r].name << setw(20) << custom[r].age<<setw(20)<<custom[r].w_purchse << "\n";
		}
	}
	cout << "-----------------------------------------------------------------\n";
}