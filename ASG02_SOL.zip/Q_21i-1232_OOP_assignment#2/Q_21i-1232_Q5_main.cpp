#include<iostream>
#include "Q_21i-1232_Q5_Header.h"
using namespace std;
int main()
{
    characters obj1(0), obj2, str;
    string line;
    char c;
    cout << " ENTER Charater 1\n =";
    cin >> c;
    obj1.set_character(c);
    cout << " ENTER Charater 2\n =";
    cin >> c;

    obj2.set_character(c);
    //------------------//
    obj1.menu(obj1, obj2);
    //------------------//
    //line = obj1.string_line();
    //cout << "Char 1 as string: " << line << endl;
    //line = obj2.string_line();
    //cout << "Char 2 as string: " << line << endl;

    return 0;
}

