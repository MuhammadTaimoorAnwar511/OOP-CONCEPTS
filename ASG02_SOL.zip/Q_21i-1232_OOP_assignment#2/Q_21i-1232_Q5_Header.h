#pragma once

using namespace std;

class characters
{
private:
    char ch;
    char plus;
    char minus;
public:
    characters()
    {
        ch = '0';
        plus = '0';
        minus = '0';
    }

    characters(int i)
    {
        ch = i;
    }
    void set_character(char c)
    {
        ch = c;
    }
    char get_character()
    {
        return ch;
    }
    //-------------------------------------------------//
    void menu(characters obj1, characters obj2);
    void is_equall_to(characters obj1, characters obj2);
    void is_not_equall_to(characters obj1, characters obj2);
    void is_greater_than(characters obj1, characters obj2);
    void is_lesser_than(characters obj1, characters obj2);
    void is_greater_than_or_equall_to(characters obj1, characters obj2);
    void is_lesser_than_or_equall_to(characters obj1, characters obj2);

    void alpha(characters    obj1, characters obj2);
    void number(characters   obj1, characters obj2);
    void is_lower(characters obj1, characters obj2);
    void is_upper(characters obj1, characters obj2);
    void to_lower(characters obj1, characters obj2);
    void to_upper(characters obj1, characters obj2);

    void charplus(characters& obj1, characters& obj2);
    void charminus(characters& obj1, characters& obj2);
    string string_line();
    //--------------------------------------------------//
};
