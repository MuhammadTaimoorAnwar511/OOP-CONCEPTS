#include<iostream>
#include"Q_21i-1232_Q4_Header.h"
using namespace std;

int main()
{
	int X, Y, id;
	float L, W, R;

	//------------------OBJECT-----------------//
	int n;
	do
	{
		cout << "ENTER NUMBER OF SHAPES YOU WANT for each figure  \n";
		cin >> n;
	} while (n < 1)
		;
	shapes* square = new shapes[n];
	shapes* rectangle = new shapes[n];
	shapes* triangle = new shapes[n];
	shapes* circle   = new shapes[n];
	shapes menu;
	//----------------------------------------//
	
		

			id = 1;
			cout << "\n-----------------------\n";
			cout << "              \nEnter data for square \n";
			for (int r = 0;r < n;r++)
			{
				square[r].set_ID(id);
				cout << "SQUARE  # " << id++<< endl;
				cout << "Enter x axis \n =";
				cin >> X;
				cout << "Enter y axis \n =";
				cin >> Y;
				square[r].set_x_axis(X);
				square[r].set_y_axis(Y);
				do {
					cout << "Enter lenght \n =";
					cin >> L;
				} while (L < 0);
				W = L;
				square[r].set_l_length(L);
				square[r].set_W_width(W);
				cout << endl;
				cout << endl;
			}

			id=1;
			cout << "\n------------------------\n";
			cout << "              \nEnter data for rectangle \n";
			for (int r = 0;r < n;r++)
			{
				rectangle[r].set_ID(id);
				cout << "RECTANGLE  # " <<id++ << endl;
				cout << "Enter x axis \n =";
				cin >> X;
				cout << "Enter y axis \n =";
				cin >> Y;
				rectangle[r].set_x_axis(X);
				rectangle[r].set_y_axis(Y);
				do
				{
					cout << "Enter lenght \n =";
					cin >> L;
				} while (L < 0);
				do
				{
					cout << "Enter width \n =";
					cin >> W;
				} while (W < 0);
				rectangle[r].set_l_length(L);
				rectangle[r].set_W_width(W);
				cout << endl;
				cout << endl;
			}

			id=1;
			cout << "\n---------------------------\n";
			cout << "              \nEnter data for triangle \n";
			for (int r = 0;r < n;r++)
			{
				triangle[r].set_ID(id);
				cout << "TRIANGLE  # " <<id++<< endl;
				cout << "Enter x axis \n =";
				cin >> X;
				cout << "Enter y axis \n =";
				cin >> Y;
				triangle[r].set_x_axis(X);
				triangle[r].set_y_axis(Y);
				do
				{
					cout << "Enter base \n =";
					cin >> L;
				} while (L < 0);
				do
				{
					cout << "Enter height \n =";
					cin >> W;
				} while (W < 0);
				triangle[r].set_l_length(L);//HIGHT //
				triangle[r].set_W_width(W);//WIDTH //
				cout << endl;
				cout << endl;
			}
			
			id = 1;
			cout << "\n--------------------------\n";
cout << "              \nEnter data for circle  \n";
			for (int r = 0;r < n;r++)
			{
				circle[r].set_ID(id);
				cout << "CIRCLE # " << id++ << endl;
				cout << "Enter x  axis \n =";
				cin >> X;
				circle[r].set_x_axis(X);
				cout << "Enter y axis \n =";
				cin >> Y;
				circle[r].set_y_axis(Y);
				do
				{
					cout << "Enter radius \n =";
					cin >> R;
				} while (R < 0);
				circle[r].set_r_radius(R);
				cout << endl;
				cout << endl;
			}
			
			//--------------------------------------------------------------------------------------------//
		
	cout << "\n---------------------------\n";
	cout << "funcall CALL\n";
	square[0].menu(square,rectangle,triangle,circle,n);
	
	cout << "\n---------------------------\n";
	//---------DELETE---------//
	delete[] square;
	delete[] rectangle;
	delete[] triangle;
	delete[] circle;
//------------------------//

	return 0;
}
