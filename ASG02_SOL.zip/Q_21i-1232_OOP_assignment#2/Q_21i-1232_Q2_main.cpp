#include <iostream>
#include <fstream>
#include <string>
#include"Q_21I-1232_Q2_Header.h"
using namespace std;
//--------------------------------------------------------------//
//------------------------------------------------------------  //

int main()
{
    int x=1;
    int text;
    player players[2];
    string mytext;// copy text from file//
    question q[10];// array of 10 question //
    // Read from the text file //
    ifstream MyReadFile("filename.txt");

    for (int r=0;r<10;r++)
    {
        getline(MyReadFile, mytext); // Output the text from the file//
        q[r].set_quest(mytext);
        
        getline(MyReadFile, mytext);
        q[r].set_possible_answer_1(mytext);
        
        getline(MyReadFile, mytext);
        q[r].set_possible_answer_2(mytext);
      
        getline(MyReadFile, mytext);
        q[r].set_possible_answer_3(mytext);
      
        getline(MyReadFile, mytext);
        q[r].set_possible_answer_4(mytext);
        cout << endl;
    }
    //-------------------------//
    q[0].set_correct_answer(1);
    q[1].set_correct_answer(3);
    q[2].set_correct_answer(1);
    q[3].set_correct_answer(2);
    q[4].set_correct_answer(4);
    q[5].set_correct_answer(1);
    q[6].set_correct_answer(4);
    q[7].set_correct_answer(3);
    q[8].set_correct_answer(1);
    q[9].set_correct_answer(3);
    //------------------------//

    for(int r=0;r<10;r++)
    {
        cout << q[r].get_quest();
        cout << endl;

        cout << q[r].get_possible_answer_1();
        cout << endl;

        cout << q[r].get_possible_answer_2();
        cout << endl;

        cout << q[r].get_possible_answer_3();
        cout << endl;

        cout << q[r].get_possible_answer_4();
        cout << endl;
     }

   q[0].game(q,players);

    // Close the file
    MyReadFile.close();

    return 0;
}

