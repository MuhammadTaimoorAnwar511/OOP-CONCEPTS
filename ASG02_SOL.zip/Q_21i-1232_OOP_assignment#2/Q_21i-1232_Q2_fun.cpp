#include <iostream>
#include <string>
#include"Q_21I-1232_Q2_Header.h"
using namespace std;


void question::game(question q[10], player players[2])
{
    int p1 = 0;// count points of player 1//
    int p2 = 0;// count points of player 2//
    string n; // player name//
    int id = 1; // player id/number //
    int opt;  // option to answer //

    cout << endl;
    /* for (int i = 0;i<10;i++)
     {
         cout << q[i].get_correct_answer();
         cout << endl;
     }
     */
    for (int r = 0;r < 2;r++)
    {
        cout << "Enter player " << id << " name \n = ";
        cin >> n;
        players[r].set_name(n);
        id++;
    }
    cout << endl;
    for (int i = 0;i < 10;)
    {
        for (int r = 0;r < 2;r++)
        {
            cout << endl;
            cout << players[r].get_name() << " Turn \n";
            cout << "YOUR Question is here \n ";

            cout << q[i].get_quest();
            cout << endl;

            cout << q[i].get_possible_answer_1();
            cout << endl;

            cout << q[i].get_possible_answer_2();
            cout << endl;

            cout << q[i].get_possible_answer_3();
            cout << endl;

            cout << q[i].get_possible_answer_4();
            cout << endl;
            cout << q[i].get_correct_answer();
            cout << endl;
            cout << "--------------------------------------------------\n";
            do
            {
                cout << "Enter your answer 1 to4 \n = ";
                cin >> opt;
            } while (opt < 1 || opt >4);
            cout << "--------------------------------------------------\n";
            cout << endl;
            if (opt == q[i].get_correct_answer())
            {
                cout << players[r].get_name() << " your answer is correct\n ";
                cout << "--------------------------------------------------\n";
                cout << "--------------------------------------------------\n";
                if (r == 0)
                {
                    ++p1;
                }
                else if (r == 1)
                {
                    ++p2;
                }
            }
            else
            {
                cout << players[r].get_name() << " your answer is wrong\n ";
                cout << "--------------------------------------------------\n";
                cout << "--------------------------------------------------\n";
            }
            i++;
        }

    }
    players[0].set_points(p1);
    players[1].set_points(p2);
    //------------------------//
    cout << endl;
    for (int r = 0;r < 2;r++)
    {
        cout << endl;
        cout << players[r].get_name() << "  " << " Total points are =  ";
        cout << players[r].get_points();
        cout << endl;
    }
    if (players[0].get_points() > players[1].get_points())
    {
        cout << players[0].get_name() << "  WINS!!!!\n";
    }
    else if (players[0].get_points() < players[1].get_points())
    {
        cout << players[1].get_name() << "  WINS!!!!\n";
    }
    else if (players[0].get_points() == players[1].get_points())
    {
        cout << "Match Draw\n";
    }
}