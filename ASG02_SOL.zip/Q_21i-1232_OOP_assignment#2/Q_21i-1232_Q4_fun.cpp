#include<iostream>
#include<iomanip>
#include"Q_21i-1232_Q4_Header.h"
using namespace std;
//----------------------------//

void shapes::menu(shapes square[], shapes rectangle[], shapes triangle[], shapes circle[], int n)
{
	int opt;
	do
	{
		cout << "SELECT OPTION\n1] CALCLUCLATE AREA\n2]LARGEST SHAPE\n3]DISPLAY\n4]EXIT\n =  = ";
		cin >> opt;
	} while (opt<1 || opt>4);

	if (opt != 4)
	{
		switch (opt)
		{
		case 1:
			square[0].cal(square, rectangle, triangle, circle, n);
			break;
		case 2:
			square[0].large_area(square, rectangle, triangle, circle, n);
			break;
		case 3:
			square[0].display(square, rectangle, triangle, circle, n);
			break;
		}
	}
	else if (opt)
	{
		cout << "\nYOU EXIT PROGRAM \n";
	}
}
void shapes::display(shapes square[], shapes rectangle[], shapes triangle[], shapes circle[], int n)
{
	cout << "\n--------------------------\n";
	cout << "\n\n values of figures \n\n";
	cout << "\n            SQUARE              \n";
	for (int i = 0;i < n;i++)
	{
		cout << "SQUARE  # " << square[i].get_ID() << endl;
		cout << "X AXIS  = " << square[i].get_x_axis() << endl;
		cout << "Y AXIS  = " << square[i].get_y_axis() << endl;
		cout << "LENGHTH = " << square[i].get_l_length() << endl;
		cout << "WIDTH   = " << square[i].get_w_width() << endl << endl;
	}

	cout << "\n--------------------------\n";
	cout << "\n            RECTANGLE              \n";
	for (int i = 0;i < n;i++)
	{
		cout << "RECTANGLE # " << rectangle[i].get_ID() << endl;
		cout << "X AXIS    = " << rectangle[i].get_x_axis() << endl;
		cout << "Y AXIS    = " << rectangle[i].get_y_axis() << endl;
		cout << "LENGHTH   = " << rectangle[i].get_l_length() << endl;
		cout << "WIDTH     = " << rectangle[i].get_w_width() << endl << endl;
	}

	cout << "\n--------------------------\n";
	cout << "\n            TRIIANGLE              \n";
	for (int i = 0;i < n;i++)
	{
		cout << "TRIANGLE  # " << triangle[i].get_ID() << endl;
		cout << "X AXIS    = " << triangle[i].get_x_axis() << endl;
		cout << "Y AXIS    = " << triangle[i].get_y_axis() << endl;
		cout << "BASE      = " << triangle[i].get_l_length() << endl;
		cout << "HEIGHT    = " << triangle[i].get_w_width() << endl << endl;
	}

	cout << "\n--------------------------\n";
	cout << "\n            CIRCLE              \n";
	for (int i = 0;i < n;i++)
	{
		cout << "CIRCLE    # " << circle[i].get_ID() << endl;
		cout << "X AXIS    = " << circle[i].get_x_axis() << endl;
		cout << "Y AXIS    = " << circle[i].get_y_axis() << endl;
		cout << "RADIUS    = " << circle[i].get_r_radius() << endl << endl;;
	}
	square[0].menu(square, rectangle, triangle, circle, n);
}
void shapes :: large_area(shapes square[], shapes rectangle[], shapes triangle[], shapes circle[], int n)
{
	float max;
	int maxid = 1;
	max = square[0].get_area();

	for(int i=0;i<n;i++)
	{
		if(max< square[i].get_area())
		{
			max = square[i].get_area();
			maxid = square[i].get_ID();
		}
		else
		{
		}
	}
	cout<<" SQUARE ID # "<< maxid<<" has largest area = "<<max<<endl;
                         //-------------//
	cout << "\n\n";
max = rectangle[0].get_area();

for (int i = 0;i < n;i++)
{
	if (max < rectangle[i].get_area())
	{
		max = rectangle[i].get_area();
		maxid= rectangle[i].get_ID();
	}
	else
	{
	}
}
cout << " RECTANGLE ID # " << maxid << " has largest area = " << max << endl;
                              //-------------//
cout << "\n\n";
max = triangle[0].get_area();

for (int i = 0;i < n;i++)
{
	if (max < triangle[i].get_area())
	{
		max = triangle[i].get_area();
		maxid =triangle[i].get_ID();
	}
	else
	{
	}
}
cout << " TRIANGLE ID # " << maxid << " has largest area = " << max << endl;
                              //-------------//
cout << "\n\n";
max = circle[0].get_area();
for (int i = 0;i < n;i++)
{
	if (max < circle[i].get_area())
	{
		max = circle[i].get_area();
		maxid = circle[i].get_ID();
	}
	else
	{
	}
}

cout << " CIRCLE ID # " << maxid << " has largest area = " << max << endl;
                         //-------------//
cout << "\n\n";
square[0].menu(square, rectangle, triangle, circle, n);
}

void shapes :: cal(shapes square[], shapes rectangle[], shapes triangle[], shapes circle[], int n)
{
	float result;
	for (int r=0;r<n;r++)
	{
		                       // square //
		result=square[r].get_l_length() * square[r].get_w_width();
		square[r].set_area(result);
		                       //rectangle //
		result = rectangle[r].get_l_length() * rectangle[r].get_w_width();
		rectangle[r].set_area(result);
		                       // triangle //
		result = triangle[r].get_l_length() * triangle[r].get_w_width();
		result = result/2;
		triangle[r].set_area(result);
		                       // circle //
		result = circle[r].get_r_radius() * circle[r].get_r_radius()*3.145;
		
		circle[r].set_area(result);
	}
	cout << "---------------------------\n";
		cout << "               SQUARE\n\n";
	for (int r = 0;r < n;r++)
	{
		cout << " Square ID  " << square[r].get_ID() << " AREA =  ";
		cout <<setprecision(3) << square[r].get_area() << endl;
	}
	cout << "---------------------------\n";
	cout << "               RECTANGLE\n\n";
	for (int r = 0;r < n;r++)
	{
		cout << " Rectangle ID  " << rectangle[r].get_ID() << " AREA =  ";
		cout<< setprecision(3) <<rectangle[r].get_area() << endl;
	}
	cout << "---------------------------\n";
	cout << "                TRIANGLE\n\n";
	for (int r = 0;r < n;r++)
	{
		cout << " Triangle ID  " << triangle[r].get_ID() << " AREA =  ";
		cout << setprecision(3) << triangle[r].get_area() << endl;
	}
	cout << "---------------------------\n";
	cout << "                CIRCLE\n\n";
	for (int r = 0;r < n;r++)
	{
		cout << " Circle ID  " << circle[r].get_ID() << " AREA =  ";
		cout <<(float)circle[r].get_area() << endl;
	}
	cout << "---------------------------\n";
	cout << "---------------------------\n";
	square[0].menu(square, rectangle, triangle, circle, n);
}