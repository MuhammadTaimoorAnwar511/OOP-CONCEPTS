#include<iostream>
#include "Q_21i-1232_Q3_Header.h "

void rational::menu(int n1, int d1, int n2, int d2, rational rat)
{
	int option;
	do
	{
		cout << "Select option\n 1)ADDITION\n 2)SUBTRACTION\n 3) MULTIPLICATION\n 4) DIVISION\n5) EXIT\n = ";
		cin >> option;
	} while (option < 1 || option >5);
	if (option != 5)
	{
		switch (option)
		{
		case 1:rat.add(n1, d1, n2, d2, rat);
			break;
		case 2:rat.sub(n1, d1, n2, d2, rat);
			break;
		case 3:rat.multi(n1, d1, n2, d2, rat);
			break;
		case 4:rat.divi(n1, d1, n2, d2, rat);
			break;
		}
		
	}
	else if (option == 5)
	{
		cout << "you exit program\n";
	}


}
//----------------------------------------------------//
//---------------------------------------------------//
void rational::simply(int n1, int d1, int n2, int d2, int denm, int ians, rational rat)
{
	int gcd=1;//greatest common divisior     //
	int n; //numerator  //
	int d;//denominator//
	int neg = 0;// controll negative sigh//

	if (ians < 0)
	{
		ians = -(ians);
		neg = 1;
	}

	for (int r = 1; r <= denm && r <= ians;r++)
	{
		if (denm % r == 0 && ians % r == 0)
		{
			gcd = r;
		}
	}

	n = ians / gcd;
	d = denm / gcd;

	if (neg == 1)
	{
		n = -(n);
	}

	rat.set_answer1n(n);
	rat.set_answer1d(d);

	cout << " Division of two fractional number in reduce form  =  ";
	cout << rat.get_answer1n();
	cout << "/";
	cout << rat.get_answer1d();
	cout << endl;
}
//---------------------------------------------------//
void rational::add(int n1, int d1, int n2, int d2, rational rat)
{
	int denm = 100;
	float fans;// answer in float //
	int ians; // asnwer in int //
	fans = ((n1 * d2) + (n2 * d1));
	fans = fans / (d1 * d2);
	cout << "Addition of two fractional number in float =  ";

	rat.set_answer2(fans);
	cout << rat.get_answer2() << endl;
	ians = fans * 100;
	//-------------------//
	rat.simply(n1, d1, n2, d2, denm, ians, rat);
	rat.menu(n1, d1, n2, d2, rat);
}
void rational::sub(int n1, int d1, int n2, int d2, rational rat)
{

	int denm = 100;
	float fans;// answer in float //
	int ians; // answer in int //
	fans = ((n1 * d2) - (n2 * d1));
	fans = fans / (d1 * d2);
	cout << "Subtraction of two fractional number in float =  ";

	rat.set_answer2(fans);
	cout << rat.get_answer2() << endl;
	ians = fans * 100;
	//-------------------//
	rat.simply(n1, d1, n2, d2, denm, ians, rat);
	rat.menu(n1, d1, n2, d2, rat);
}
void rational::multi(int n1, int d1, int n2, int d2, rational rat)
{
	int denm = 100;
	float fans;// answer in float//
	int ians; // asnwer in int //
	fans = (n1 * n2);
	fans = fans / (d1 * d2);
	cout << "Multiplication of two fractional number in float =  ";

	rat.set_answer2(fans);
	cout << rat.get_answer2() << endl;
	ians = fans * 100;
	
		
	
	//-------------------//
	rat.simply(n1, d1, n2, d2, denm, ians, rat);
	rat.menu(n1, d1, n2, d2, rat);
}
void rational::divi(int n1, int d1, int n2, int d2, rational rat)
{
	int denm = 100;
	float fans;// answer in float //
	int ians; // asnwer in int //
	fans = (n1 * d2);
	fans = fans / (d1 * n2);
	cout << "Division of two fractional number in float =  ";

	rat.set_answer2(fans);
	cout << rat.get_answer2() << endl;
	ians = fans * 100;
	//-------------------//
	rat.simply(n1, d1, n2, d2, denm, ians, rat);
	rat.menu(n1, d1, n2, d2, rat);
}

