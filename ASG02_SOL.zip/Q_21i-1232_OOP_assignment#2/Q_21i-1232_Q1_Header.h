#pragma once
#include<iostream>
#include<string>
using namespace std;

struct cours
{
	int      course_code;
	string   course_name;
	int    course_grades;
};

class student
{
private:

	int    roll_number;
	char   name;
	int    batch;
	int    course_reg;
	float  gpa;
	string degree;
	string birth;
	cours* course;

public:

	student()
	{
		roll_number = 0;
		name = '0';
		batch = 0;
		gpa = 0;
		degree = "SE";
		birth = "january";
		course_reg = 5;
		course = new cours[course_reg];

		course[0].course_name = "Physics";
		course[1].course_name = "Match";
		course[2].course_name = "Science";
		course[3].course_name = "Oops";
		course[4].course_name = "English";

		for (int i = 0;i < 5;i++)
		{
			course[i].course_code = i;
		}
	}
	//---------------------------------------------------------------------------//
	void set_students_detail(int roll, char naam, int bath, float GPA, string degre, string birthday)
	{
		roll_number = roll;
		name = naam;
		batch = bath;
		gpa = GPA;
		degree = degre;
		birth = birthday;
	}
	void set_course_grade(int r, int marks)
	{
		course[r].course_grades = marks;
	}
	//---------------------------------------------------------------------------//
	int get_roll_number()
	{
		return roll_number;
	}
	char get_name()
	{
		return name;
	}
	int get_batch()
	{
		return batch;

	}
	float get_gpa()
	{
		return gpa;
	}
	string get_degree()
	{
		return degree;
	}
	string get_birth()
	{
		return birth;
	}
	int get_course_reg()
	{
		return course_reg;
	}
	string get_courename(int n)
	{
		return course[n].course_name;
	}

	int get_course_code(int n)
	{
		return course[n].course_code;
	}
	int get_course_grade(int n)
	{
		return course[n].course_grades;
	}

	//---------------------------------------------------------------------------//
	void copy(const student& std)
	{
		course_reg = std.course_reg;

	}

	//--------------------------//
	void menu_inialized(student std[],int n);
	void display(student std[], int n);//display full information //
	void courses_display(student std[], int n, int  specific_student);// display courses name//
	void grade_display(student std[], int n, int  specific_student);// display grade //
	void compare_course(student std[], int n, int  specific_course);// compare course grade //
	//------------------------------//
	~student()
	{
		delete[] course;
	}
};