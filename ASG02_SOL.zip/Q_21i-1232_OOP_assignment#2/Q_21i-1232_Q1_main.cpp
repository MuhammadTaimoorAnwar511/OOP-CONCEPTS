#include<iostream>
#include<ctime>
#include<iomanip>
#include"Q_21i-1232_Q1_Header.h"
using namespace std;

int main()
{
	srand(time(NULL));
	int  n;  // dynamic memeory fot student //
	//--------------------------------------------------------------------------//
	do
	{
		cout << "Enter number of student \n= ";
		cin >> n;
	} while (n <= 0);
	student* std = new student[n];
	//-------------------------------------------------------------------------//
	int         random;// generate random number //
	int         marks;// generate random marks /
	int         roll = 0; // roll number increment 
	int         bath = 21; // batch year //
	float       GPA;//gpa//
	char        naam; // name of each student via rand //
	string      degre;  // degree of each student random //
	string      birthday; // birtdate of students //
	int         specific_student;// specific student index //
	int         specific_course;// specific course index //
	//------------------------------------------------------------------------//

	//-------------------------------------------------------------------------//
	for (int s = 0;s < n;s++)
	{
		naam = 'a' + rand() % 26;
		random = rand() % 4;
		//------------------------//
		if (random == 0)
		{
			degre = " SoftWare ";
		}
		else if (random == 1)
		{
			degre = " Artificail Intelligence ";
		}
		else if (random == 2)
		{
			degre = " Computer Software ";
		}
		else if (random == 3)
		{
			degre = " English ";
		}

		random = rand() % 5;
		if (random == 0)
		{
			GPA = 3.6;
		}
		else if (random == 1)
		{
			GPA = 3.2;
		}
		else if (random == 2)
		{
			GPA = 2.5;
		}
		else if (random == 3)
		{
			GPA = 2.3;
		}
		else if (random == 4)
		{
			GPA = 3.9;
		}


		//----------------------------------//
		random = rand() % 3;

		if (random == 0)
		{
			birthday = "10/JAN/2000";
		}
		else  if (random == 1)
		{
			birthday = "1/FEB/1999";
		}
		else  if (random == 2)
		{
			birthday = "15/DEC/2002";
		}
		else  if (random == 3)
		{
			birthday = "20/SEPT/2005";
		}

		//---------------------------------//
		std[s].set_students_detail(roll, naam, bath, GPA, degre, birthday);
		++roll;

		for (int r = 0;r < 5;r++)
		{
			marks = rand() % 100;
			std[s].set_course_grade(r, marks);
		}
	}

	//----------------------------//
	std[0].menu_inialized(std, n);
	//----------------------------//
	delete[]std;
	//----------------------------//
	return 0;

}