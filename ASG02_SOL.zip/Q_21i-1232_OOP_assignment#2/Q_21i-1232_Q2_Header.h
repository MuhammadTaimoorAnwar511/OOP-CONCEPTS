#pragma once
#include <iostream>
#include <fstream>
#include <string>
using namespace std;
class player
{

private:
    string name;
    int points;

public:

    void set_name(string n)
    {
        name = n;
    }
    void set_points(int y)
    {
        points = y;
    }
    string get_name()
    {
        return name;
    }
    int get_points()
    {
        return points;
    }

    player()
    {
        name = "0";
        points = 0;
    }

};
//---------------------------------------------------------------------------------//
class question
{
private:
    string quest;
    string possible_answer_1;
    string possible_answer_2;
    string possible_answer_3;
    string possible_answer_4;
    int correct_answer;
public:
    question()
    {
        quest = "0";
        possible_answer_1 = "0";
        possible_answer_2 = "0";
        possible_answer_3 = "0";
        possible_answer_4 = "0";
        correct_answer = 0;
    }

    void set_quest(string mytext)
    {
        quest = mytext;
    }
    void set_possible_answer_1(string mytext)
    {
        possible_answer_1 = mytext;
    }
    void set_possible_answer_2(string mytext)
    {
        possible_answer_2 = mytext;
    }
    void set_possible_answer_3(string mytext)
    {
        possible_answer_3 = mytext;
    }
    void set_possible_answer_4(string mytext)
    {
        possible_answer_4 = mytext;
    }
    void set_correct_answer(int text)
    {
        correct_answer = text;
    }

    //--------------------//
    string get_quest()
    {
        return quest;
    }
    string get_possible_answer_1()
    {
        return possible_answer_1;
    }
    string get_possible_answer_2()
    {
        return possible_answer_2;
    }
    string get_possible_answer_3()
    {
        return possible_answer_3;
    }
    string get_possible_answer_4()
    {
        return possible_answer_4;
    }
    int get_correct_answer()
    {
        return correct_answer;
    }
    void game(question q[10], player players[2]);
};
