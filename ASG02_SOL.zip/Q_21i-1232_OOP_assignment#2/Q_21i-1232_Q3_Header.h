#pragma once

#include<iostream>
using namespace std;

class rational
{
private:
	int num1;
	int num2;
	int den1;
	int den2;
	int reduce;
	int answer1n;
	int answer1d;
	float answer2;
public:
	rational()
	{
		cout << " Constructure Call \n";
		num1 = 1;
		num2 = 1;
		den1 = 1;
		den2 = 1;
		reduce = 1;
		answer1n = 1;
		answer1d = 1;
		answer2 = 1;
	}
	//---------------------//
	void set_num1(int n1)
	{
		num1 = n1;
	}
	void set_num2(int n2)
	{
		num2 = n2;
	}
	void set_den1(int d1)
	{
		den1 = d1;
	}
	void set_den2(int d2)
	{
		den2 = d2;
	}
	void set_answer1n(int n)
	{
		answer1n = n;
	}
	void set_answer1d(int d)
	{
		answer1d = d;
	}
	void set_answer2(float fans)
	{
		answer2 = fans;
	}
	//---------------------//
	int get_num1()
	{
		return num1;
	}
	int get_num2()
	{
		return num2;
	}
	int get_den1()
	{
		return den1;
	}
	int get_den2()
	{
		return den2;
	}
	int get_reduce()
	{
		return reduce;
	}
	int get_answer1n()
	{
		return answer1n;
	}
	int get_answer1d()
	{
		return answer1d;
	}
	float get_answer2()
	{
		return answer2;
	}
	//-----------------------------------------------//
	void menu(int n1, int d1, int n2, int d2, rational rat);
	void simply(int n1, int d1, int n2, int d2, int denm, int ians, rational rat);
	void add(int n1, int d1, int n2, int d2, rational rat);
	void sub(int n1, int d1, int n2, int d2, rational rat);
	void multi(int n1, int d1, int n2, int d2, rational rat);
	void divi(int n1, int d1, int n2, int d2, rational rat);

	//---------------------------------------------------//
};

