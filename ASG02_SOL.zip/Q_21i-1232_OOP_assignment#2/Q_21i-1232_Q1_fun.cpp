#include<iostream>
#include<ctime>
#include<iomanip>
#include"Q_21i-1232_Q1_Header.h"
using namespace std;
//----------------------------//
void student::display(student std[], int n)
{
	cout << "\n-----------------------------------------\n";
	for (int i = 0;i < n;i++)
	{
		cout << "----------------------------------------\n";
		cout << " ROLL NUMBER  = " << setw(12);
		cout << std[i].get_roll_number() << "\n";
		cout << " NAME = " << setw(20);
		cout << std[i].get_name() << "\n";
		cout << " birthday   =  " << setw(20);;
		cout << std[i].get_birth() << "\n";
		cout << " BATCH  =  " << setw(17);
		cout << std[i].get_batch() << "\n";
		cout << " DEGREE  =  " << setw(20);
		cout << std[i].get_degree() << "\n";
		cout << " GPA  =  " << setw(20);
		cout << std[i].get_gpa() << "\n";

		cout << "\nSubject of STUDENTS \n";
		for (int j = 0;j < 5;j++)
		{
			cout << std[i].get_course_code(j) << ")" << setw(20);
			cout << std[i].get_courename(j) << setw(20);
			cout << std[i].get_course_grade(j) << "\n";
		}
		cout << endl;
		cout << "----------------------------------------\n";
	}
	cout << "\n----------------------------------------------------------------\n";
	std[0].menu_inialized(std, n);
	cout << "\n----------------------------------------------------------------\n";
}

void student::courses_display(student std[], int n, int  specific_student)
{
	int i = specific_student;
	cout << "ROLL # " << std[i].get_roll_number() << " NAME ";
	cout << std[i].get_name() << " is registered in following courses" << "\n";
	for (int j = 0;j < 5;j++)
	{
		cout << std[i].get_course_code(j) << ")" << setw(20);
		cout << std[i].get_courename(j) << "\n";
	}

	cout << "\n----------------------------------------------------------------\n";
	std[0].menu_inialized(std, n);
	cout << "\n----------------------------------------------------------------\n";
}

void student::grade_display(student std[], int n, int  specific_student)
{
	int i = specific_student;
	cout << "ROLL # " << std[i].get_roll_number() << " NAME ";
	cout << std[i].get_name() << " has  following grade in courses" << "\n";
	for (int j = 0;j < 5;j++)
	{
		cout << std[i].get_course_code(j) << ")" << setw(20);
		cout << std[i].get_courename(j) << setw(20);
		cout << std[i].get_course_grade(j) << "\n";
	}
	cout << "\n----------------------------------------------------------------\n";
	std[0].menu_inialized(std, n);
	cout << "\n----------------------------------------------------------------\n";
}

void student::compare_course(student std[], int n, int  specific_course)
{
	int c = specific_course;

	int max = std[0].course[c].course_grades;
	int index = 0;
	for (int i = 0;i < n;i++)
	{
		if (std[i].course[c].course_grades > max)
		{
			max = std[i].course[c].course_grades;
			index = i;
		}
	}
	cout << "ROLL # " << std[index].get_roll_number() << " NAME ";
	cout << std[index].get_name() << " has highest marks in " << std[index].course[c].course_name << " = ";
	cout << std[index].course[c].course_grades;

	cout << "\n----------------------------------------------------------------\n";
	std[0].menu_inialized(std, n);
}
void student::menu_inialized(student std[], int n)
{
	int         specific_student;// specific student index //
	int         specific_course;// specific course index //
	int select_option;
	//-------------------------------------------------------------------------//
	//-------------------------------------------------------------------------//
	do
	{
		cout << " Enter number 1 to 5 \n1)DISPLAY COURSES \n2)DISPLAY GRADES \n3)DISPLAY \n4)COMPARE STUDENT COURSES \n5)SORT STUDENT \n=  ";
		cin >> select_option;
	} while (select_option < 1 || select_option>5);

	switch (select_option)
	{

	case 1:
		do {
			cout << " Enter student ID from 0 to " << (n - 1) << " to display courses list \n";
			cin >> specific_student;
		} while (specific_student<0 || specific_student >(n - 1));
		std[0].courses_display(std, n, specific_student);
		break;

	case 2:
		do
		{
			cout << " Enter student ID from 0 to " << (n - 1) << " to display  courses marks " << "\n";
			cin >> specific_student;
		} while (specific_student<0 || specific_student >(n - 1));
		std[0].grade_display(std, n, specific_student);
		break;

	case 3:
		std[0].display(std, n);
		break;

	case 4:
		do
		{
			cout << " Enter course id from 0 to 4 to  compare specific course marks \n";
			cout << "0] Physics\n1] Math\n2]Science\n3]oop\n4]English \n = ";
			cin >> specific_course;
		} while (specific_course < 0 || specific_course >4);
		std[0].compare_course(std, n, specific_course);
		break;
	}
	cout << "\n----------------------------------------------------------------\n";
	std[0].menu_inialized(std, n);
}

//-----------------------------------------------------------------------------//
//-----------------------------------------------------------------------------//