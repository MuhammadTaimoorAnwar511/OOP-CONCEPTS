#include<iostream>
#include"Q_21i-1232_Q3_Header.h"

int main()
{
	int n1, n2, d1, d2, option;
	rational rat;
	cout << " ------------------------------------\n\n";
	cout << "Enter first Rational Number            \n";
	cout << " ------------------------------------\n\n";
	do
	{
		cout << " Enter first number Numerator     \n =   ";
		cin >> n1;
	} while (n1 == 0);
	do
	{
		cout << " Enter first number denominator   \n =   ";
		cin >> d1;
	} while (d1 == 0);

	cout << "Enter second Rational Number           \n";
	cout << " ------------------------------------\n\n";
	do
	{
		cout << " Enter second number Numerator    \n =   ";
		cin >> n2;
	} while (n2 == 0);
	do
	{
		cout << " Enter second number denominator  \n =   ";
		cin >> d2;
	} while (d2 == 0);

	cout << " ------------------------------------\n  ";
	rat.set_num1(n1);
	rat.set_num2(n2);
	rat.set_den1(d1);
	rat.set_den2(d2);
	cout << " ------------------------------------\n  ";
	cout << " ----------FUNCTIONS-----------------\n  ";
	rat.menu(n1, d1, n2, d2, rat);
	cout << "FINISH \n";

	return 0;
}
