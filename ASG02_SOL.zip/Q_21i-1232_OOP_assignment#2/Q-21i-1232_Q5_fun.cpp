#include <iostream>
#include <fstream>
#include <string>
#include"Q_21i-1232_Q5_Header.h"
using namespace std;


//--------------------------------------------------------------------------------------//
//--------------------------------------------------------------------------------------//
void characters::menu(characters obj1, characters obj2)
{
    cout << "\n------------------------------------------------------------------------\n";
    int option;
    do
    {
        cout << "SELECT OPTION \n 1)IS EQUALL TOO\n2)IS NOT EQUALL TO\n3)GREATER THAN\n4)LESSER THAN\n5)IS GREATER THAN OR EQUALL TO\n6)IS LESSER THAN OR EQUAL TO\n7)ALPHABETS\n8)NUMBER\n9)IS LOWER CASE\n10)IS UPPER CASE\n11)CONVERT TO LOWER CASE \n12)CONVERT TO UPPER CASE\n13)SUM OF TWO CHARACTERS\n14)MINUS OF TWO CHARACTERS\n15)STRING FOR OBJ 1\n16)STRING FOR OBJ 2\n=  ";
        cin >> option;
    } while (option < 1 || option>16);

        switch (option)
        {
        case 1: obj1.is_equall_to(obj1, obj2);
            break;
        case 2: obj1.is_not_equall_to(obj1, obj2);
            break;
        case 3: obj1.is_greater_than(obj1, obj2);
            break;
        case 4: obj1.is_lesser_than(obj1, obj2);
            break;
        case 5: obj1.is_greater_than_or_equall_to(obj1, obj2);
            break;
        case 6: obj1.is_lesser_than_or_equall_to(obj1, obj2);
            break;
        case 7: obj1.alpha(obj1, obj2);
            break;
        case 8: obj1.number(obj1, obj2);
            break;
        case 9:obj1.is_lower(obj1, obj2);
            break;
        case 10:obj1.is_upper(obj1, obj2);
            break;
        case 11:obj1.to_lower(obj1, obj2);
            break;
        case 12:obj1.to_upper(obj1, obj2);
            break;
        case 13:obj1.charplus(obj1, obj2);
            break;
        case 14:obj1.charminus(obj1, obj2);
            break;
        case 15: cout<< obj1.string_line();
            break;
        case 16: cout<< obj2.string_line();
            break;
        }
        cout << endl;
        cout << "\n------------------------------------------------------------------------\n";

        obj1.menu(obj1, obj2);
    

}
//---------------------------------------------------------------------------------------//
//---------------------------------------------------------------------------------------//
void characters::is_equall_to(characters obj1, characters obj2)
{
    if ((int)obj1.get_character() == (int)obj2.get_character())
    {
        cout << obj1.get_character() << " is equall to  " << obj2.get_character();
    }

    else
    {
        cout << obj1.get_character() << " is not equall to  " << obj2.get_character();
    }
    cout << endl;
    cout << "\n------------------------------------------------------------------------\n";
    obj1.menu(obj1, obj2);
}

void characters::is_not_equall_to(characters obj1, characters obj2)
{
    if ((int)obj1.get_character() != (int)obj2.get_character())
    {
        cout << obj1.get_character() << "  is not equall to  " << obj2.get_character();
    }

    else
    {
        cout << obj1.get_character() << " is  equall to   " << obj2.get_character();
    }
    cout << endl;
    cout << "\n------------------------------------------------------------------------\n";
    obj1.menu(obj1, obj2);
}
void characters::is_greater_than(characters obj1, characters obj2)
{
    if ((int)obj1.get_character() > (int)obj2.get_character())
    {
        cout << obj1.get_character() << " is greater than  " << obj2.get_character();
    }

    else
    {
        cout << obj1.get_character() << " is not greater than   " << obj2.get_character();
    }
    cout << endl;
    cout << "\n------------------------------------------------------------------------\n";
    obj1.menu(obj1, obj2);
}
void characters::is_lesser_than(characters obj1, characters obj2)
{
    if ((int)obj1.get_character() < (int)obj2.get_character())
    {
        cout << obj1.get_character() << " is lesser than  " << obj2.get_character();
    }

    else
    {
        cout << obj1.get_character() << " is not lesser than   " << obj2.get_character();
    }
    cout << endl;
    cout << "\n------------------------------------------------------------------------\n";
    obj1.menu(obj1, obj2);
}
void characters::is_greater_than_or_equall_to(characters obj1, characters obj2)
{
    if ((int)obj1.get_character() >= (int)obj2.get_character())
    {
        cout << obj1.get_character() << " is greater than or equall to   " << obj2.get_character();
    }

    else
    {
        cout << obj1.get_character() << "  is not  greater than or equall to    " << obj2.get_character();
    }
    cout << endl;
    cout << "\n------------------------------------------------------------------------\n";
    obj1.menu(obj1, obj2);
}
void characters::is_lesser_than_or_equall_to(characters obj1, characters obj2)
{
    if ((int)obj1.get_character() <= (int)obj2.get_character())
    {
        cout << obj1.get_character() << " is lesser than or equall to   " << obj2.get_character();
    }

    else
    {
        cout << obj1.get_character() << "  is not  lesser than or equall to    " << obj2.get_character();
    }
    cout << endl;
    cout << "\n------------------------------------------------------------------------\n";
    obj1.menu(obj1, obj2);
}
void characters::alpha(characters obj1, characters obj2)
{
    if ((int)obj1.get_character() >= 'a' && (int)obj1.get_character() <= 'z' || (int)obj1.get_character() >= 'A' && (int)obj1.get_character() <= 'Z')
    {
        cout << obj1.get_character() << " is alphabet \n";
    }

    else
    {
        cout << obj1.get_character() << " is not  alphabet \n";
    }

    if ((int)obj2.get_character() >= 'a' && (int)obj2.get_character() <= 'z' || (int)obj2.get_character() >= 'A' && (int)obj2.get_character() <= 'Z')
    {
        cout << obj2.get_character() << " is alphabet \n";
    }

    else
    {
        cout << obj2.get_character() << " is not  alphabet \n";
    }

    cout << endl;
    cout << "\n------------------------------------------------------------------------\n";
    obj1.menu(obj1, obj2);
}

void characters::number(characters obj1, characters obj2)
{
    if ((int)obj1.get_character() >= '0' && (int)obj1.get_character() <= '9')
    {
        cout << obj1.get_character() << " is number  \n";
    }

    else
    {
        cout << obj1.get_character() << " is not  number \n";
    }

    if ((int)obj2.get_character() >= '0' && (int)obj2.get_character() <= '9')
    {
        cout << obj2.get_character() << " is number \n";
    }

    else
    {
        cout << obj2.get_character() << " is not  number \n";
    }

    cout << endl;
    cout << "\n------------------------------------------------------------------------\n";
    obj1.menu(obj1, obj2);
}
void characters::is_lower(characters obj1, characters obj2)
{
    if ((int)obj1.get_character() >= 'a' && (int)obj1.get_character() <= 'z')
    {
        cout << obj1.get_character() << " is lower case  \n";
    }

    else if ((int)obj1.get_character() >= 'A' && (int)obj1.get_character() <= 'Z')
    {
        cout << obj1.get_character() << " is not lower case  \n";
    }
    else
    {
        cout << obj1.get_character() << " has no upper and lower case  \n";
    }

    if ((int)obj2.get_character() >= 'a' && (int)obj2.get_character() <= 'z')
    {
        cout << obj2.get_character() << " is lower case  \n";
    }

    else if ((int)obj2.get_character() >= 'A' && (int)obj2.get_character() <= 'Z')
    {
        cout << obj2.get_character() << " is not lower case  \n";
    }
    else
    {
        cout << obj2.get_character() << " has no upper and lower case  \n";
    }

    cout << endl;
    cout << "\n------------------------------------------------------------------------\n";
    obj1.menu(obj1, obj2);
}
void characters::is_upper(characters obj1, characters obj2)
{
    if ((int)obj1.get_character() >= 'A' && (int)obj1.get_character() <= 'Z')
    {
        cout << obj1.get_character() << " is upper case  \n";
    }

    else if ((int)obj1.get_character() >= 'a' && (int)obj1.get_character() <= 'z')
    {
        cout << obj1.get_character() << " is not upper case  \n";
    }
    else
    {
        cout << obj1.get_character() << " has no upper and lower case  \n";
    }

    if ((int)obj2.get_character() >= 'A' && (int)obj2.get_character() <= 'Z')
    {
        cout << obj2.get_character() << " is upper case  \n";
    }

    else if ((int)obj2.get_character() >= 'a' && (int)obj2.get_character() <= 'z')
    {
        cout << obj2.get_character() << " is not upper case  \n";
    }
    else
    {
        cout << obj2.get_character() << " has  no upper and lower case  \n";
    }

    cout << endl;
    cout << "\n------------------------------------------------------------------------\n";
    obj1.menu(obj1, obj2);
}
void characters::to_lower(characters obj1, characters obj2)
{
    char c;
    if ((int)obj1.get_character() >= 'a' && (int)obj1.get_character() <= 'z')
    {
        cout << obj1.get_character() << " is already in lower case \n";
    }

    else if ((int)obj1.get_character() >= 'A' && (int)obj1.get_character() <= 'Z')
    {
        cout << obj1.get_character() << " is converted to  lower case ";
        c = obj1.get_character() + 32;
        obj1.set_character(c);
        cout << obj1.get_character() << "\n";
    }
    else
    {
        cout << obj1.get_character() << " has no upper and lower case  \n";
    }
    if ((int)obj2.get_character() >= 'a' && (int)obj2.get_character() <= 'z')
    {
        cout << obj2.get_character() << " is already in lower case \n";
    }

    else if ((int)obj2.get_character() >= 'A' && (int)obj2.get_character() <= 'Z')
    {
        cout << obj2.get_character() << " is converted to  lower case ";
        c = obj2.get_character() + 32;
        obj2.set_character(c);
        cout << obj2.get_character() << "\n";
    }
    else
    {
        cout << obj2.get_character() << " has no upper and lower case  \n";
    }


    cout << endl;
    cout << "\n------------------------------------------------------------------------\n";
    obj1.menu(obj1, obj2);
}

void characters::to_upper(characters obj1, characters obj2)
{
    char c;
    if ((int)obj1.get_character() >= 'A' && (int)obj1.get_character() <= 'Z')
    {
        cout << obj1.get_character() << " is already in upper case \n";
    }

    else if ((int)obj1.get_character() >= 'a' && (int)obj1.get_character() <= 'z')
    {
        cout << obj1.get_character() << " is converted to  upper case ";
        c = obj1.get_character() - 32;
        obj1.set_character(c);
        cout << obj1.get_character() << "\n";
    }
    else
    {
        cout << obj1.get_character() << " has no upper and lower case  \n";
    }

    if ((int)obj2.get_character() >= 'A' && (int)obj2.get_character() <= 'A')
    {
        cout << obj2.get_character() << " is already in upper case \n";
    }

    else if ((int)obj2.get_character() >= 'a' && (int)obj2.get_character() <= 'z')
    {
        cout << obj2.get_character() << " is converted to  upper case ";
        c = obj2.get_character() - 32;
        obj2.set_character(c);
        cout << obj2.get_character() << "\n";
    }
    else
    {
        cout << obj2.get_character() << " has no upper and lower case  \n";
    }


    cout << endl;
    cout << "\n------------------------------------------------------------------------\n";
    obj1.menu(obj1, obj2);
}
void characters::charplus(characters& obj1, characters& obj2)
{
    int c;

    if ((int)obj1.get_character() >= 48 && (int)obj1.get_character() <= 57 && (int)obj2.get_character() >= 48 && (int)obj2.get_character() <= 57)
    {
        c = ((int)obj1.get_character() - 48) + ((int)obj2.get_character() - 48);
        cout << "sum of two characters " << obj1.get_character() << " and " << obj2.get_character() << " is = " << (int)c;
    }
    else
    {
        c = ((int)obj1.get_character() - 48) + ((int)obj2.get_character() - 48);
        cout << "sum of two characters " << obj1.get_character() << " and " << obj2.get_character() << " is = " << (char)c;
    }
    obj1.menu(obj1, obj2);
}
void characters::charminus(characters& obj1, characters& obj2)
{
    int c;

    if ((int)obj1.get_character() >= 48 && (int)obj1.get_character() <= 57 && (int)obj2.get_character() >= 48 && (int)obj2.get_character() <= 57)
    {
        c = ((int)obj1.get_character() - 48) - ((int)obj2.get_character() - 48);
        cout << "sum of two characters " << obj1.get_character() << " and " << obj2.get_character() << " is = " << (int)c;
    }
    else
    {
        c = ((int)obj1.get_character() - 48) - ((int)obj2.get_character() - 48);
        cout << "sum of two characters " << obj1.get_character() << " and " << obj2.get_character() << " is = " << (char)c;
    }
    obj1.menu(obj1, obj2);
}

string characters::string_line()
{
    string str(1, this->ch);
        return str;
        
}

//--------------------------------------------------------------------------------------//
//--------------------------------------------------------------------------------------//

