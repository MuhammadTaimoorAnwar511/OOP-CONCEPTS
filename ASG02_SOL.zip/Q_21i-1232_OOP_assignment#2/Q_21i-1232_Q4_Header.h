#pragma once
#include<iostream>
using namespace std;

class shapes
{

private:

	int ID;
	int x;
	int y;
	float l;
	float w;
	float r;
	
	float area;

public:
	shapes()
	{
		ID = 0;
		x = 0;
		y = 0;
		l = 0;
		w = 0;
		r = 0;
		area = 0;
	}

	shapes(int X, int Y, float L, float W, float R, float B, float H, int id, float AREA)
	{
		ID = id;
		x = X;
		y = Y;
		l = L;
		w = W;
		r = R;
		area = AREA;
	}
	//-----//
	void set_ID(int id)
	{
		ID = id;
	}
	void set_x_axis(int X)
	{
		x = X;
	}
	void set_y_axis(int Y)
	{
		y = Y;
	}
	void set_l_length(int L)
	{
		l = L;
	}
	void set_W_width(int W)
	{
		w = W;
	}
	void set_r_radius(int R)
	{
		r = R;
	}
	void set_area(int res)
	{
		area = res;
	}
	//-----//
	int get_ID()
	{
		return ID;
	}
	int get_x_axis()
	{
		return x;
	}
	int get_y_axis()
	{
		return y;
	}
	float get_l_length()
	{
		return l;
	}
	float get_w_width()
	{
		return w;
	}
	float get_r_radius()
	{
		return r;
	}
	float get_area()
	{
		return area;
	}
	void display(shapes square[], shapes rectangle[], shapes triangle[], shapes circle[], int n);
	void cal(shapes square[],shapes rectangle[],shapes triangle[],shapes circle[], int n);
	void menu(shapes square[], shapes rectangle[], shapes triangle[], shapes circle[], int n);
	void large_area(shapes square[], shapes rectangle[], shapes triangle[], shapes circle[], int n);
};  